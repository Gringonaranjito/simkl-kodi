import io
import os
import re
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'resources', 'site-packages'))


def cleanup_settings():
    # Kodi auto-names id-less legacy settings labelN/actionN, and its counter grows on every settings reload, so stale ids pile up in user settings (#1208).
    # Must run before the first xbmcaddon.Addon() loads the values, otherwise they are saved back.
    try:
        from xbmcvfs import translatePath
    except ImportError:
        from xbmc import translatePath

    path = translatePath('special://profile/addon_data/plugin.video.elementum/settings.xml')
    try:
        with io.open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        cleaned = re.sub(r'[ \t]*<setting id="(?:label|action)\d+"[^>]*?(?:/>|>[^<]*</setting>)[ \t]*\r?\n?', '', content)
        if cleaned != content:
            with io.open(path, 'w', encoding='utf-8') as f:
                f.write(cleaned)
    except Exception:
        pass


cleanup_settings()

# Lightweight startup listener; do not load the engine before an explicit request.
import xbmc
import xbmcgui
window = xbmcgui.Window(10000)
monitor = xbmc.Monitor()
request_key = 'Elementum.OnDemand.Request'
state_key = 'Elementum.OnDemand.State'
window.setProperty(state_key, 'waiting')
xbmc.log('[Elementum on-demand] Waiting for explicit request', xbmc.LOGINFO)
try:
    while not monitor.abortRequested():
        if window.getProperty(request_key) == '1':
            window.setProperty(state_key, 'starting')
            xbmc.log('[Elementum on-demand] Starting requested service', xbmc.LOGINFO)
            from elementum import service, config
            config.init()
            service.run()
            break
        if monitor.waitForAbort(0.25):
            break
except Exception:
    import traceback
    xbmc.log('[Elementum on-demand] ' + traceback.format_exc(), xbmc.LOGERROR)
    window.setProperty(state_key, 'failed')
finally:
    window.clearProperty(request_key)
    if window.getProperty(state_key) != 'failed':
        window.clearProperty(state_key)

