import os
import sys
import time
import socket
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon


def wait_for_engine():
    window = xbmcgui.Window(10000)
    window.setProperty('Elementum.OnDemand.Request', '1')
    addon = xbmcaddon.Addon('plugin.video.elementum')
    host = addon.getSetting('remote_host') or '127.0.0.1'
    try:
        port = int(addon.getSetting('remote_port') or '65220')
    except ValueError:
        return False
    monitor = xbmc.Monitor()
    deadline = time.monotonic() + 90
    while not monitor.abortRequested() and time.monotonic() < deadline:
        if window.getProperty('Elementum.OnDemand.State') == 'failed':
            break
        try:
            with socket.create_connection((host, port), timeout=0.5):
                if window.getProperty('Elementum.OnDemand.State') == 'ready':
                    return True
        except OSError:
            pass
        if monitor.waitForAbort(0.5):
            break
    return False


if wait_for_engine():
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'resources', 'site-packages'))
    from elementum import navigation
    navigation.run()
else:
    xbmc.log('[Elementum on-demand] Engine did not become reachable', xbmc.LOGERROR)
    xbmcgui.Dialog().notification('Elementum', 'Engine did not start. Check Kodi log.', xbmcgui.NOTIFICATION_ERROR, 5000)
    if len(sys.argv) > 1 and int(sys.argv[1]) >= 0:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
