# -*- coding: utf-8 -*-
"""
    Otaku Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import sys

from resources.lib.ui import control
from resources.lib.ui.router import router_process


# A Kodi video plugin is re-entered for *every* folder navigation.  Never
# present the automatic changelog from a child route or a playable item.
# 0 = once per Kodi session; 1 = once per installed version; 2 = never.
def _maybe_show_changelog():
    import os
    from urllib.parse import urlparse
    try:
        # Changelog is only shown upon opening the add-on's root menu.
        # Manual View Changelog has its own dedicated route in Main.py.
        plugin = urlparse(sys.argv[0])
        if plugin.scheme != 'plugin' or plugin.netloc != control.ADDON_ID:
            return
        if plugin.path not in ('', '/') or (len(sys.argv) > 2 and sys.argv[2]):
            return
        if control.getBool('first_time'):
            return
        mode = control.getInt('showchangelog')
        if mode == 2:
            return
        seen_key = control.ADDON_ID + '.changelog.session.' + control.ADDON_VERSION
        if control.homeWindow.getProperty(seen_key) == '1':
            return
        marker = os.path.join(control.dataPath, 'changelog_last_shown.txt')
        if mode == 1:
            try:
                with open(marker, encoding='utf-8') as handle:
                    if handle.read().strip() == control.ADDON_VERSION:
                        return
            except OSError:
                pass
        # Persist BEFORE displaying. Kodi can re-enter the add-on while a dialog
        # is open; marking first prevents nested windows and repeated popups.
        control.homeWindow.setProperty(seen_key, '1')
        if mode == 1:
            try:
                os.makedirs(control.dataPath, exist_ok=True)
                with open(marker, 'w', encoding='utf-8') as handle:
                    handle.write(control.ADDON_VERSION)
            except OSError as exc:
                control.log('Changelog marker write failed: %s' % exc, 'warning')
        import service
        service.getChangeLog()
    except Exception as exc:
        # A cosmetic notice must never break movie playback or navigation.
        control.log('Automatic changelog suppressed: %s' % exc, 'warning')


_maybe_show_changelog()

if __name__ == "__main__":
    from resources.lib import simkl_recovery
    state = simkl_recovery.begin(control.dataPath)
    try:
        # Only an explicit root-menu invocation requests the on-demand engine.
        # Never start it from the background service or while in Safe Mode.
        from urllib.parse import urlsplit
        entry = urlsplit(sys.argv[0])
        if (entry.scheme == 'plugin' and entry.netloc == control.ADDON_ID
                and entry.path in ('', '/') and not entry.query
                and len(sys.argv) > 2 and sys.argv[2] in ('', '?')
                and not state['safe_mode'] and state['elementum_enabled']):
            from resources.lib.simkl_elementum_start import request_engine
            request_engine()
        from resources.lib import Main  # noQA
        plugin_url = control.get_plugin_url(sys.argv[0])
        plugin_params = control.get_plugin_params(sys.argv[2])
        # Recovery routes must remain accessible even if a provider is broken.
        if simkl_recovery.read(control.dataPath)['safe_mode'] and plugin_url not in (
                '', 'simkl_recovery', 'tools') and not plugin_url.startswith('simkl_recovery/'):
            plugin_url = 'simkl_recovery'
        router_process(plugin_url, plugin_params)
    except Exception as exc:
        simkl_recovery.change(control.dataPath, last_error=str(exc)[:500])
        raise
    else:
        simkl_recovery.finish(control.dataPath, True)
        control.log('Finished Simkl navigation: %s' % plugin_url)

