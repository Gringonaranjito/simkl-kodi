"""Opt-in Google Drive bookmark transport. Credentials remain in local settings."""
import os, json, time, hashlib, uuid, threading
_wake = threading.Event()
def wake_worker(): _wake.set()
def wait_worker(timeout):
    signaled = _wake.wait(timeout)
    _wake.clear()
    return signaled
from urllib.request import Request, urlopen
from urllib.parse import urlencode
from resources.lib.ui import control

BASE='https://www.googleapis.com/drive/v3/'
_cache={}; _last=0; _token=''; _expiry=0; _identity=''; _folder=''; _error=''
def enabled():
    return control.getBool('simkl.drive.enabled')
def setting(k): return control.getSetting('simkl.drive.'+k) or ''
def request(url, method='GET', data=None, token=None, content='application/json'):
    headers={'Content-Type':content}
    if token: headers['Authorization']='Bearer '+token
    with urlopen(Request(url,data=data,headers=headers,method=method),timeout=12) as r:
        return json.loads(r.read() or b'{}')
def access():
    global _token,_expiry,_identity,_folder,_last,_cache
    identity=hashlib.sha256((setting('client')+'\n'+setting('refresh')).encode()).hexdigest()
    if identity!=_identity:
        _identity=identity; _token=''; _folder=''; _last=0; _cache={}
    if _token and time.time()<_expiry:return _token
    if not all(setting(k) for k in ('client','secret','refresh')):raise ValueError('Google Drive authorization required')
    data=urlencode(dict(client_id=setting('client'),client_secret=setting('secret'),refresh_token=setting('refresh'),grant_type='refresh_token')).encode()
    obj=request('https://oauth2.googleapis.com/token','POST',data,content='application/x-www-form-urlencoded')
    _token=obj['access_token']; _expiry=time.time()+int(obj.get('expires_in',3600))-60
    return _token
def api(path,method='GET',obj=None):
    return request(BASE+path,method,json.dumps(obj).encode() if obj is not None else None,access())
def listing(q):
    out=[]; page=''
    while True:
        args={'q':q,'fields':'nextPageToken,files(id,name,modifiedTime,mimeType)','pageSize':100}
        if page:args['pageToken']=page
        result=api('files?'+urlencode(args));out.extend(result.get('files',[]));page=result.get('nextPageToken')
        if not page:return out
def folder():
    global _folder
    access()
    if not _folder:
        rows=listing("trashed = false and name = 'Simkl Sync' and mimeType = 'application/vnd.google-apps.folder'")
        if len(rows)>1:raise ValueError('Multiple Simkl Sync folders; resolve duplicates in Drive')
        _folder=rows[0]['id'] if rows else api('files','POST',{'name':'Simkl Sync','mimeType':'application/vnd.google-apps.folder'})['id']
    return _folder
def queue_dir():
    p=os.path.join(control.dataPath,'drive-resume-outbox');os.makedirs(p,exist_ok=True);return p
def scope():
    # User explicitly dedicates this private Drive account to one SIMKL profile.
    return hashlib.sha256(setting('client').encode()).hexdigest()[:16]
def enqueue(key,record):
    if not enabled():return
    from resources.lib.simkl_resume import _atomic_local
    obj={k:record[k] for k in ('seconds','total','percentage','updated','reset','finished','completed','unwatched','title','year') if k in record}
    obj.update(key=key,scope=scope())
    _atomic_local(os.path.join(queue_dir(),uuid.uuid4().hex+'.json'),obj)
def children(fid):
    return listing("trashed = false and '%s' in parents" % fid)

def subfolder(parent,name):
    rows=listing("trashed = false and '%s' in parents and name = '%s' and mimeType = 'application/vnd.google-apps.folder'" % (parent,name.replace("\\","\\\\").replace("'","\\'")))
    if len(rows)>1:raise ValueError('Duplicate Drive folder')
    return rows[0]['id'] if rows else api('files','POST',{'name':name,'parents':[parent],'mimeType':'application/vnd.google-apps.folder'})['id']

def terminal(obj):return bool(obj.get('finished') or obj.get('completed') or obj.get('reset'))

def scan(fid):
    import re
    records={}; locations={}
    def walk(parent,depth):
        for row in children(parent):
            name=row['name']
            if row.get('mimeType')=='application/vnd.google-apps.folder':
                if depth<4 and (depth or name in ('Movies','TV Shows','System')):walk(row['id'],depth+1)
                continue
            if not (name.startswith('resume-'+scope()+'-') or (depth and name.endswith('.json'))):continue
            obj=api('files/'+row['id']+'?alt=media');key=obj.get('key','')
            if obj.get('scope')!=scope() or not re.fullmatch(r'movie:\d+|episode:\d+:\d+:\d+',key):continue
            locations.setdefault(key,[]).append((row,parent,obj))
            if float(obj.get('updated',0))>float(records.get(key,{}).get('updated',0)):records[key]=obj
    walk(fid,0)
    return records,locations

def refresh(force=False):
    global _cache,_last,_error
    if not enabled():return {}
    if not force and time.time()-_last<60:return _cache
    try:
        _cache,_=scan(folder());_last=time.time();_error=''
    except Exception as exc:_error=type(exc).__name__;control.log('Simkl Drive download failed: '+_error,'warning')
    return _cache

def put(parent,name,obj,existing=None):
    if existing:
        request('https://www.googleapis.com/upload/drive/v3/files/'+existing+'?uploadType=media','PATCH',json.dumps(obj).encode(),access())
        return existing
    boundary=uuid.uuid4().hex
    meta=json.dumps({'name':name,'parents':[parent],'mimeType':'application/json'})
    body=('--'+boundary+'\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n'+meta+'\r\n--'+boundary+'\r\nContent-Type: application/json\r\n\r\n'+json.dumps(obj)+'\r\n--'+boundary+'--\r\n').encode()
    return request('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart','POST',body,access(),'multipart/related; boundary='+boundary)['id']

def destination(fid,key,obj):
    import re
    parts=key.split(':');sid=parts[1]
    if terminal(obj):return subfolder(fid,'System'),key.replace(':','-')+'.json'
    category=subfolder(fid,'Movies' if parts[0]=='movie' else 'TV Shows')
    # Stable ID suffix allows title changes without creating another folder.
    suffix=' - '+sid
    matches=[x for x in children(category) if x.get('mimeType')=='application/vnd.google-apps.folder' and x['name'].endswith(suffix)]
    if len(matches)>1:raise ValueError('Duplicate media folder')
    title=obj.get('title') or ''
    if not title and not matches:
        from resources.lib.simkl_media import _call
        details=_call(('/movies/' if parts[0]=='movie' else '/tv/')+sid)
        title=details.get('title') or 'SIMKL';obj['year']=details.get('year')
    title=re.sub(r'[\x00-\x1f/\\]',' ',title).strip()[:150] or 'SIMKL'
    if obj.get('year'):title+=' (%s)'%obj['year']
    media=matches[0]['id'] if matches else subfolder(category,title+suffix)
    if parts[0]=='movie':return media,'resume.json'
    return subfolder(media,'Season %02d'%int(parts[2])),'Episode %02d.json'%int(parts[3])

def prune_empty(fid):
    import re
    for category in children(fid):
        if category.get('mimeType') != 'application/vnd.google-apps.folder' or category['name'] not in ('Movies','TV Shows'):
            continue
        for media in children(category['id']):
            if media.get('mimeType') != 'application/vnd.google-apps.folder' or not re.search(r' - \d+$',media['name']):continue
            if category['name']=='TV Shows':
                for season in children(media['id']):
                    if season.get('mimeType')=='application/vnd.google-apps.folder' and re.fullmatch(r'Season \d+',season['name']) and not children(season['id']):
                        api('files/'+season['id'],'PATCH',{'trashed':True})
            if not children(media['id']):api('files/'+media['id'],'PATCH',{'trashed':True})

def flush():
    global _error,_last
    if not enabled():return
    try:
        fid=folder(); records,locations=scan(fid); pending={}
        for name in sorted(os.listdir(queue_dir())):
            if not name.endswith('.json'):continue
            path=os.path.join(queue_dir(),name)
            with open(path,encoding='utf-8') as f:obj=json.load(f)
            if obj.get('scope')!=scope():continue
            key=obj['key'];pending.setdefault(key,[]).append(path)
            if float(obj['updated'])>float(records.get(key,{}).get('updated',0)):records[key]=obj
        for key,obj in records.items():
            old=locations.get(key,[])
            parent,name=destination(fid,key,obj)
            same=[row for row,p,rec in old if p==parent and row['name']==name]
            if len(old)==1 and same and old[0][2]==obj and key not in pending:continue
            keep=put(parent,name,obj,same[0]['id'] if same else None)
            check=api('files/'+keep+'?alt=media')
            if check!=obj:raise ValueError('Drive verification failed')
            for row,p,rec in old:
                if row['id']==keep:continue
                current=api('files/'+row['id']+'?alt=media')
                if current==rec and float(current['updated'])<=float(obj['updated']):api('files/'+row['id'],'PATCH',{'trashed':True})
            for path in pending.get(key,[]):os.remove(path)
        prune_empty(fid)
        _last=0;_error=''
    except Exception as exc:_error=type(exc).__name__;control.log('Simkl Drive upload pending: '+_error,'warning')
def tools():
    flush();records=refresh(True)
    control.ok_dialog('Google Drive Sync',('Enabled' if enabled() else 'Disabled')+'\nBookmarks: '+str(len(records))+'\nPending: '+str(len(os.listdir(queue_dir())))+'\n'+(_error or 'No reported error'))


def import_authorization():
    import xbmcgui, xbmcvfs
    dialog=xbmcgui.Dialog()
    path=dialog.browseSingle(1,'Select Simkl Drive authorization','files','.json')
    if not path:return
    try:
        with xbmcvfs.File(path) as f:
            raw=f.read(16385)
        if len(raw)>16384:raise ValueError('File too large')
        obj=json.loads(raw)
        if obj.get('format')!='simkl-drive-auth-v1':raise ValueError('Invalid format')
        creds={k:obj[k] for k in ('client','secret','refresh')}
        if not all(isinstance(v,str) and 0<len(v)<4096 for v in creds.values()):raise ValueError('Invalid credentials')
        if not dialog.yesno('Google Drive authorization','Import credentials for your private Simkl Drive account?'):return
        data=urlencode(dict(client_id=creds['client'],client_secret=creds['secret'],refresh_token=creds['refresh'],grant_type='refresh_token')).encode()
        token=request('https://oauth2.googleapis.com/token','POST',data,content='application/x-www-form-urlencoded')['access_token']
        request(BASE+'files?'+urlencode({'pageSize':1,'fields':'files(id)'}),token=token)
    except Exception as exc:
        dialog.ok('Google Drive authorization','Import failed: '+type(exc).__name__+'. Existing settings unchanged.')
        return
    old={k:setting(k) for k in creds}; was_enabled=enabled()
    try:
        for k,v in creds.items():control.setSetting('simkl.drive.'+k,v)
        control.setBool('simkl.drive.enabled',True)
    except Exception:
        for k,v in old.items():control.setSetting('simkl.drive.'+k,v)
        control.setBool('simkl.drive.enabled',was_enabled)
        dialog.ok('Google Drive authorization','Could not save settings.')
        return
    removed=False
    try:removed=xbmcvfs.delete(path)
    except Exception:pass
    dialog.ok('Google Drive authorization','Connection verified. Restart Kodi before syncing. '+('Authorization file removed.' if removed else 'Delete the authorization file from Downloads now.'))
