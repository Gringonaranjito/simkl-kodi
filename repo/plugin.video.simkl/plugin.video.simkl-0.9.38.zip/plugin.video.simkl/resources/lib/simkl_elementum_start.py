"""Start our on-demand Elementum only from foreground Simkl navigation."""
import socket
import time
import xbmc
import xbmcaddon
import xbmcgui


def request_engine():
    try:
        addon = xbmcaddon.Addon('plugin.video.elementum')
        window = xbmcgui.Window(10000)
        # Official releases do not implement this property protocol.
        if addon.getAddonInfo('version') not in ('0.1.114.1', '0.1.119.1', '0.1.119.2', '0.1.119.3'):
            return False
        window.setProperty('Elementum.OnDemand.Request', '1')
        return True
    except Exception as exc:
        xbmc.log('[Simkl] Elementum startup request unavailable: %s' % exc, xbmc.LOGWARNING)
        return False


def wait_for_engine(port):
    # Direct HTTP source-list routes may be opened before startup finishes.
    # Native Elementum routes already have their own readiness check.
    if not request_engine():
        return
    monitor = xbmc.Monitor()
    window = xbmcgui.Window(10000)
    deadline = time.monotonic() + 45
    while not monitor.abortRequested() and time.monotonic() < deadline:
        if window.getProperty('Elementum.OnDemand.State') == 'failed':
            break
        try:
            with socket.create_connection(('127.0.0.1', port), timeout=0.5):
                if xbmcaddon.Addon('plugin.video.elementum').getAddonInfo('version') != '0.1.119.3' or window.getProperty('Elementum.OnDemand.State') == 'ready':
                    return
        except OSError:
            pass
        if monitor.waitForAbort(0.25):
            break
    raise RuntimeError('Elementum engine not ready; try the native Elementum fallback')
