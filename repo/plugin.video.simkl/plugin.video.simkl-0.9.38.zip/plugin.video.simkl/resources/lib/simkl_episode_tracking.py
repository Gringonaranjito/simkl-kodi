"""Conservative per-episode Kodi tracker for provider-first TV navigation.

Does not control player lifecycle, change containers, or trigger playback.
A show identity must come from a recently browsed Simkl watchlist; season and
episode must be unambiguously reported by Kodi or the media filename.
"""
import json
import os
import re
import time
from urllib.parse import unquote
from resources.lib.ui import control

WINDOW = 45 * 60
THRESHOLD = 80

def _file(name):
    folder = os.path.join(control.dataPath, 'simkl_episodes')
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, name)

def _load(path):
    try:
        with open(path, encoding='utf-8') as f:
            obj = json.load(f)
        return obj if isinstance(obj, dict) else {}
    except (ValueError, OSError):
        return {}

def _save(path, value):
    temp = path + '.tmp'
    with open(temp, 'w', encoding='utf-8') as f:
        json.dump(value, f)
    os.replace(temp, path)

def _norm(text):
    return re.sub(r'[^a-z0-9]+', '', str(text or '').lower())

def remember_shows(records):
    """Keep only a short-lived mapping; cannot assume which item was clicked."""
    items = []
    for rec in records:
        ids = rec.get('ids') or {}
        sid = ids.get('simkl')
        if not str(sid or '').isdigit() or not rec.get('title'):
            continue
        items.append({'simkl':int(sid),'title':str(rec['title']),
                      'tmdb':str(ids.get('tmdb') or ''),
                      'year':rec.get('year')})
    old = _load(_file('recent_shows.json'))
    previous = old.get('shows') if time.time()-float(old.get('updated') or 0) < WINDOW else []
    combined = {str(r['simkl']): r for r in previous if isinstance(r,dict) and 'simkl' in r}
    combined.update({str(r['simkl']):r for r in items})
    _save(_file('recent_shows.json'), {'updated':time.time(), 'shows':list(combined.values())[:1500]})

def bookmark(sid, season, episode):
    return _load(_file('progress-%s-%02d-%03d.json' % (int(sid),int(season),int(episode))))

def watched_set(sid):
    obj = _load(_file('watched-%s.json' % int(sid)))
    return set((int(p[0]),int(p[1])) for p in obj.get('episodes', []) if isinstance(p,list) and len(p)==2)

def save_watched(sid, season, episode):
    done = watched_set(sid)
    done.add((int(season),int(episode)))
    _save(_file('watched-%s.json' % int(sid)), {'episodes':sorted([list(x) for x in done]),'updated':time.time()})
    path = _file('progress-%s-%02d-%03d.json' % (int(sid),int(season),int(episode)))
    _save(path, {'completed':True, 'updated':time.time()})

def save_partial(sid, season, episode, pct, seconds, total):
    if not 0 < pct < THRESHOLD: return
    path = _file('progress-%s-%02d-%03d.json' % (int(sid),int(season),int(episode)))
    _save(path, {'percentage':round(pct,2),'seconds':int(seconds),'total':int(total),
                 'updated':time.time(),'completed':False})

def reset_partial(sid, season, episode):
    path = _file('progress-%s-%02d-%03d.json' % (int(sid), int(season), int(episode)))
    _save(path, {'percentage': 0, 'seconds': 0, 'updated': time.time(), 'reset': True})


def last_partial(sid):
    folder = os.path.dirname(_file('recent_shows.json'))
    prefix = 'progress-%s-' % int(sid)
    result = []
    for name in os.listdir(folder):
        if name.startswith(prefix) and name.endswith('.json'):
            p = _load(os.path.join(folder,name))
            if not p.get('completed') and 0 < float(p.get('percentage') or 0) < THRESHOLD:
                parts = name[9:-5].split('-')
                if len(parts)==3:
                    result.append((float(p.get('updated') or 0),int(parts[1]),int(parts[2]),p))
    return max(result,default=None)

def _episode_from_meta(item):
    show = str(item.get('showtitle') or '').strip()
    title = str(item.get('title') or item.get('label') or '')
    filepath = unquote(str(item.get('file') or ''))
    try:
        season, episode = int(item.get('season')), int(item.get('episode'))
    except (TypeError, ValueError):
        season, episode = -1, -1
    candidate = title + ' ' + filepath.rsplit('/',1)[-1]
    matches = {(int(a),int(b)) for a,b in re.findall(r'(?i)(?<!\w)s(\d{1,2})[. _-]*e(\d{1,3})(?!\d)',candidate)}
    if len(matches)>1: return None
    if matches:
        pair=next(iter(matches))
        if season >= 0 and episode >= 1 and pair!=(season,episode): return None
        season,episode=pair
    if season<0 or episode<1: return None
    return show,title,filepath,season,episode

def _match_record(records, info):
    show,title,file_path,season,episode=info
    item_text = (title+' '+file_path.rsplit('/',1)[-1]).lower()
    matched=[]
    for rec in records:
        name=_norm(rec.get('title'))
        if not name: continue
        if _norm(show)==name or (not show and name in _norm(item_text)):
            matched.append(rec)
    # Never guess if 2 shows share the same title; Kodi's showtitle is preferable.
    return matched[0] if len(matched)==1 else None

def _seconds(t):
    if not isinstance(t,dict):return 0
    return int(t.get('hours') or 0)*3600 + int(t.get('minutes') or 0)*60+int(t.get('seconds') or 0)

def arm_episode(sid, season, episode, title, mode):
    saved = bookmark(sid, season, episode)
    _save(_file('pending.json'), {'simkl':int(sid),'season':int(season),'episode':int(episode),
        'title':title,'updated':time.time(),'resume':int(saved.get('seconds') or 0) if mode=='resume' else 0})

_current = None

def poll():
    global _current
    from resources.lib.simkl_playback_tracking import _playing_metadata
    playing = _playing_metadata()
    if not playing:
        if _current:
            if not _current.get('completed') and _current.get('pct',0)>0:
                control.log('Simkl episode partial saved at %.1f%% %s S%02dE%02d' %
                    (_current['pct'],_current['title'],_current['season'],_current['episode']),'info')
            _current = None
        return
    item,props=playing
    info = _episode_from_meta(item)
    records=_load(_file('recent_shows.json'))
    rec = _match_record(records.get('shows') or [],info) if info and time.time()-float(records.get('updated') or 0)<=WINDOW else None
    pending = _load(_file('pending.json'))
    from resources.lib.simkl_playback_tracking import _elementum_playing
    if pending and time.time()-float(pending.get('updated') or 0)<900 and _elementum_playing(item):
        pair = (pending['season'],pending['episode'])
        # Require corroborating episode metadata or filename; never track an unrelated stream.
        if info and info[3:]==pair and (not info[0] or _norm(info[0])==_norm(pending['title'])) and (rec is None or rec['simkl']==pending['simkl']):
            rec = pending
    if info and not rec and _current and info[3:]==_current['key'][1:] and _elementum_playing(item) and item.get('file')==_current.get('file'):
        rec={'simkl':_current['key'][0],'title':_current['title']}
    if not info or not rec:
        return
    show,title,file_path,season,episode=info
    # A metadata identity, not merely an unrelated HTTP playback session.
    # Require an actual show title or a filename containing the show's title.
    key=(rec['simkl'],season,episode)
    if _current is None or _current.get('key')!=key:
        _current={'key':key,'title':rec['title'],'season':season,'episode':episode,
                  'first_seen':time.time(),'completed':(season,episode) in watched_set(rec['simkl']),
                  'last_saved':0,'file':item.get('file')}
        control.log('Simkl TV tracking recognized %s S%02dE%02d' %
            (rec['title'],season,episode),'info')
    pct=float(props.get('percentage') or 0)
    if not 0<=pct<=100:return
    total=_seconds(props.get('totaltime'))
    seconds=_seconds(props.get('time'))
    if total<=0 and seconds>0 and pct>0:
        total=int(seconds*100/pct)
    _current['pct']=pct
    if rec is pending and not _current.get('resume_checked'):
        _current['resume_checked']=True
        target=int(pending.get('resume') or 0)
        _save(_file('pending.json'), {})
        if target>seconds+10 and total>target:
            try:
                from resources.lib.simkl_playback_tracking import _jsonrpc
                pid=next(p['playerid'] for p in _jsonrpc('Player.GetActivePlayers', {}) if p.get('type')=='video')
                _jsonrpc('Player.Seek', {'playerid':pid,'value':{'time':{'hours':target//3600,'minutes':target//60%60,'seconds':target%60,'milliseconds':0}}})
                return
            except Exception as exc:
                control.log('Simkl TV resume seek failed: %s' % exc,'warning')
    if (pct >= 1 or seconds >= 120) and pct < THRESHOLD and not _current['completed'] and not _current.get('watching_checked'):
        _current['watching_checked'] = True
        try:
            from resources.lib.simkl_media import promote_planned_title
            promote_planned_title('shows', rec['simkl'])
        except Exception as exc:
            control.log('Simkl TV watching status update failed: %s' % exc, 'warning')
    if 0<pct<THRESHOLD and (pct>=1 or seconds>=120) and time.time()-_current['last_saved']>=5 and not _current['completed']:
        save_partial(rec['simkl'],season,episode,pct,seconds,total)
        _current['last_saved']=time.time()
    if pct<THRESHOLD or _current['completed']:return
    # Claim locally before posting, to avoid repeated history writes on errors.
    # Log failure visibly rather than incorrectly claiming remote completion.
    _current['completed']=True
    try:
        from resources.lib.simkl_media import _post
        _post('/sync/history', {'shows':[{'ids':{'simkl':rec['simkl']},
            'seasons':[{'number':season,'episodes':[{'number':episode}]}]}]})
        save_watched(rec['simkl'],season,episode)
        control.log('Simkl TV 80%% sync accepted %s S%02dE%02d at %.1f%%' %
            (rec['title'],season,episode,pct),'info')
        control.notify('Simkl — Episode Completed', '%s S%02dE%02d — %.0f%% watched' %
            (rec['title'],season,episode,pct))
    except Exception as exc:
        control.log('Simkl TV episode history update failed %s S%02dE%02d: %s' %
            (rec['title'],season,episode,exc),'warning')
