"""Tracks a movie explicitly chosen in Simkl across Elementum playback.

The selected Simkl ID, not Elementum's often incomplete display metadata,
identifies the movie.  The session must start soon after selecting a source,
be an Elementum stream, and must not explicitly identify another film.
"""
import json
import os
import re
import time
import xbmc
from resources.lib.ui import control

ARM_TTL = 12 * 60  # Time to start playback after opening a Simkl-filtered source list.

def _path():
    return os.path.join(control.dataPath, 'elementum_pending_movie.json')

def _write(data):
    os.makedirs(control.dataPath, exist_ok=True)
    dest = _path()
    tmp = dest + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as handle:
        json.dump(data, handle)
    os.replace(tmp, dest)

def _read():
    try:
        with open(_path(), 'r', encoding='utf-8') as handle:
            value = json.load(handle)
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}

def arm_movie(simkl_id, tmdb_id, title, year):
    if not (str(simkl_id).isdigit() and str(tmdb_id).isdigit() and title and year):
        return
    from resources.lib.simkl_resume import get_resume_request
    resume_request = get_resume_request(simkl_id)
    _write({'simkl': int(simkl_id), 'tmdb': int(tmdb_id), 'title': str(title),
            'year': int(year), 'armed': time.time(), 'sent': False,
            'started': False, 'last_seen': 0, 'last_reason': '',
            'return_done': False, 'resume_to':int(resume_request.get('seconds') or 0),
            'resume_pct': float(resume_request.get('percentage') or 0), 'resume_done': False})

def _norm(s):
    return re.sub(r'[^a-z0-9]+', '', str(s or '').lower())

def _jsonrpc(method, params):
    raw = xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}))
    return json.loads(raw).get('result') or {}

def _playing_metadata():
    active = _jsonrpc('Player.GetActivePlayers', {})
    ids = [x.get('playerid') for x in active if x.get('type') == 'video'] if isinstance(active, list) else []
    if not ids: return None
    pid = ids[0]
    item = _jsonrpc('Player.GetItem', {'playerid':pid,'properties':['title','year','file','uniqueid','showtitle','season','episode']}).get('item') or {}
    props = _jsonrpc('Player.GetProperties', {'playerid':pid,'properties':['time','totaltime','percentage']})
    return item, props

def _movie_matches(item, arm):
    """Reject explicit conflicts; allow incomplete Kodi/Elementum metadata.

    The movie ID comes from the Simkl selection. Elementum can return the bare
    title with no release year, so that omission is not a reason to discard a
    confirmed Elementum stream started from the filtered source list.
    """
    if item.get('type') == 'episode' or item.get('showtitle'):
        return False
    if item.get('season', -1) not in (-1, 0, None):
        return False
    unique = item.get('uniqueid') or {}
    if isinstance(unique, dict) and unique.get('tmdb'):
        return str(unique['tmdb']) == str(arm['tmdb'])
    yr = item.get('year')
    if yr and str(yr).isdigit() and int(yr) != arm['year']:
        return False
    title = str(item.get('title') or item.get('label') or '')
    if not title:
        # Elementum sometimes omits the title entirely.
        return True
    years = [int(y) for y in re.findall(r'(?<!\d)(?:19\d{2}|20\d{2})(?!\d)', title)]
    if years and arm['year'] not in years:
        return False
    if _norm(arm['title']) not in _norm(title):
        return False
    return True


# IMPORTANT: No playlist mutation or automatic Container.Update on player stop.
# Elementum controls its own playback/exit lifecycle. The Simkl background
# monitor only reads playback position and reports watch history.

def _elementum_playing(item):
    # Elementum's Go daemon normally streams via /files/<torrent path>. The
    # returned address may use the device LAN IP, not only localhost. Require
    # the stream route and a network URL; matching title/year is checked separately.
    from urllib.parse import urlsplit
    path = str(item.get('file') or '')
    if path.startswith('plugin://plugin.video.elementum/'):
        return True
    try:
        parts = urlsplit(path)
        return parts.scheme in ('http', 'https') and '/files/' in parts.path and bool(parts.hostname)
    except ValueError:
        return False


def _seconds(value):
    if not isinstance(value, dict):
        return 0
    return (int(value.get('hours') or 0)*3600 + int(value.get('minutes') or 0)*60 +
            int(value.get('seconds') or 0))


def _record_reason(arm, reason):
    # Log transitions, not every 2s poll. Don't write log spam to disk.
    if arm.get('last_reason') != reason:
        arm['last_reason'] = reason
        _write(arm)
        control.log('Simkl movie tracker: %s' % reason, 'info')


def poll_once():
    arm = _read()
    if not arm:
        return
    # Keep observing an already-completed session long enough to record stop.
    if arm.get('sent') and not arm.get('started'):
        return
    now = time.time()
    # The browse action can precede starting a torrent by a few minutes.
    # Crucially, do NOT expire while a movie is playing or paused. Seeking
    # past 80% should count on the next 2-second poll.
    if not arm.get('started') and now - float(arm.get('armed') or 0) > ARM_TTL:
        _record_reason(arm, 'No playback began within 12 minutes; session expired')
        return
    current = _playing_metadata()
    if not current:
        # End of stream: save unfinished playback in Simkl using its scrobble API.
        # The existing history sync at >=80% remains the sole completion path.
        if arm.get('started') and not arm.get('stopped') and now - float(arm.get('last_seen') or 0) >= 3:
            arm['stopped'] = True
            _write(arm)
            if not arm.get('sent') and arm.get('pct', 0) < 80:
                try:
                    from resources.lib.simkl_resume import save_progress
                    saved = save_progress(arm, arm.get('seconds', 0), arm.get('total', 0), scrobble=True)
                    if saved:
                        control.log('Simkl bookmark saved on stop: %s at %.1f%%' % (arm['title'], arm.get('pct') or 0), 'info')
                        control.notify('Simkl — Progress Saved', '%s — %.0f%% watched' % (arm['title'], arm.get('pct') or 0))
                    else:
                        control.log('Simkl bookmark not saved: no valid partial progress for %s' % arm['title'], 'warning')
                except Exception as exc:
                    control.log('Simkl resume save at stop failed: %s' % exc, 'warning')
            arm['sent'] = True
            _write(arm)
        return
    item, props = current
    if not _elementum_playing(item):
        _record_reason(arm, 'Player is not an Elementum stream')
        return
    if not _movie_matches(item, arm):
        label = str(item.get('title') or item.get('label') or '')[:90]
        _record_reason(arm, 'Elementum playback metadata did not identify selected movie: %s' % label)
        return
    if not arm.get('started'):
        arm['started'] = True
        arm['first_seen'] = now
        control.log('Simkl tracking playback started for %s (%s)' % (arm['title'], arm['year']), 'info')
    if not arm.get('selected_source'):
        try:
            from resources.lib.simkl_resume import detect_torrent
            source = detect_torrent(arm['simkl'], item)
            if source:
                arm['selected_source'] = source
        except Exception as exc:
            control.log('Simkl torrent matching unavailable: %s' % exc, 'warning')
    arm['last_seen'] = now
    arm['stopped'] = False
    # Kodi percentage is based on current seek position, not wall clock time.
    pct = float(props.get('percentage') or 0)
    if pct < 0 or pct > 100:
        pct = 0
    arm['pct'] = pct
    arm['total'] = _seconds(props.get('totaltime')) or int(arm.get('total') or 0)
    arm['seconds'] = _seconds(props.get('time'))
    # Some Elementum builds omit time/total but still report a valid percentage.
    # Preserve that percentage so a partial-watch indicator can be displayed.
    # Elementum may supply playback percentage but no totaltime property.
    # If we have an elapsed time, infer a best-effort runtime for bookmarking.
    if not arm['total'] and arm['seconds'] > 0 and pct > 0:
        arm['total'] = int(round(arm['seconds'] * 100.0 / pct))
    # Only seek when user explicitly selected Resume. Do not affect normal playback.
    if (arm.get('resume_to') or arm.get('resume_pct')) and not arm.get('resume_done') and now - float(arm.get('first_seen') or now) >= 5:
        if arm['total'] > 0:
            try:
                pid = next(p['playerid'] for p in _jsonrpc('Player.GetActivePlayers', {}) if p.get('type') == 'video')
                target = float(arm['resume_to']) or (arm['total'] * float(arm.get('resume_pct') or 0) / 100)
                target = min(target, arm['total'] * 0.95)
                if target > 0:
                    t = int(target)
                    _jsonrpc('Player.Seek', {'playerid':pid, 'value':{'time':{
                        'hours': t // 3600, 'minutes': (t % 3600) // 60,
                        'seconds':t % 60, 'milliseconds':0}}})
                    control.log('Simkl resume requested seek to %d seconds' % int(target), 'info')
            except Exception as exc:
                control.log('Simkl resume seek not supported: %s' % exc, 'warning')
            arm['resume_done'] = True
    # Only promote a confirmed partial playback, once per armed session.
    if 1 <= pct < 80 and not arm.get('sent') and not arm.get('watching_checked'):
        arm['watching_checked'] = True
        _write(arm)
        try:
            from resources.lib.simkl_media import promote_planned_title
            promote_planned_title('movies', arm['simkl'])
        except Exception as exc:
            control.log('Simkl movie watching status update failed: %s' % exc, 'warning')
    # Record progress locally for this device; Simkl sync is event-based, not polling.
    if 0 < pct < 80 and now - float(arm.get('last_saved') or 0) >= 5:
        try:
            from resources.lib.simkl_resume import save_progress
            if save_progress(arm, arm['seconds'], arm['total'], scrobble=False):
                if not arm.get('bookmark_logged'):
                    control.log('Simkl local bookmark created: %s at %.1f%% (%ds / %ds)' %
                                (arm['title'], pct, arm['seconds'], arm['total']), 'info')
                    arm['bookmark_logged'] = True
                arm['last_saved'] = now
            elif not arm.get('bookmark_skip_logged'):
                control.log('Simkl bookmark unavailable despite playback progress: %s %.1f%%' % (arm['title'], pct), 'warning')
                arm['bookmark_skip_logged'] = True
        except Exception as exc:
            control.log('Simkl local progress save failed: %s' % exc, 'warning')
    _write(arm)
    if pct < 80 or arm.get('sent'):
        return
    # Claim once BEFORE the network call, preventing duplicate viewing history
    # if Kodi loses the API acknowledgement. We never initiate playback here.
    arm['sent'] = True
    arm['claimed_at'] = now
    _write(arm)
    try:
        from resources.lib.simkl_media import _post
        result = _post('/sync/history', {'movies': [{'ids': {'simkl': arm['simkl']}}]})
        control.log('Simkl 80%% movie watched sync accepted (%s) at %.1f%%: %s' %
                    (arm['simkl'], pct, result), 'info')
        control.notify('Simkl — Completed', '%s (%s) — %.0f%% watched' % (arm['title'], arm['year'], pct))
        try:
            from resources.lib.simkl_resume import clear_progress
            clear_progress(arm['simkl'])
        except Exception as exc:
            control.log('Simkl progress cleanup failed: %s' % exc, 'warning')
    except Exception as exc:
        control.log('Simkl watched sync FAILED for %s at %.1f%%, not auto-retrying: %s' %
                    (arm['simkl'], pct, exc), 'warning')


def run_monitor():
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        try:
            from resources.lib.simkl_episode_tracking import poll as poll_episode
            poll_episode()
        except Exception as exc:
            control.log('Simkl TV monitor check failed: %s' % exc, 'warning')
        try:
            from resources.lib.simkl_anime_fallback_tracking import poll as poll_anime
            poll_anime()
        except Exception as exc:
            control.log('Simkl anime fallback monitor check failed: %s' % exc, 'warning')
        try: poll_once()
        except Exception as exc:
            control.log('Simkl movie tracking check failed: %s' % exc, 'warning')
        if monitor.waitForAbort(2): break
