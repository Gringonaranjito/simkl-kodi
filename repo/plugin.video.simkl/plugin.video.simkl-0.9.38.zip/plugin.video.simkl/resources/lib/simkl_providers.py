"""Simkl external-provider manager.

External Kodi add-ons are sandboxed plugins. We do not enumerate their private
scrapers as if they were native providers or assume their URLs are playable.
"""
import json
import xbmc
import xbmcaddon
import xbmcgui
from resources.lib.ui import control, utils

# Only confirmed non-torrent playback integrations appear here. Some providers
# may offer additional source types internally; users configure them separately.
PROVIDERS = (
    {'id':'plugin.video.scrubsv2','name':'Scrubs V2','media':('movies','shows'),
     'kind':'External browser','note':'Opens Scrubs V2. It does not return source links to Simkl.'},
    {'id':'plugin.video.otaku','name':'Otaku (original)','media':('anime','movies'),
     'kind':'External anime browser','note':'Opens the original Otaku add-on, with its own source filters.'},
    {'id':'plugin.video.plex','name':'Plex for Kodi','media':('movies','shows'),
     'kind':'Media library','note':'Opens your Plex app. Plex access and authentication are separate.'},
    {'id':'plugin.video.jellyfin','name':'Jellyfin for Kodi','media':('movies','shows'),
     'kind':'Media library','note':'Opens your Jellyfin app. Access is configured separately.'},
    {'id':'plugin.video.emby','name':'Emby for Kodi','media':('movies','shows'),
     'kind':'Media library','note':'Opens your Emby app. Access is configured separately.'},
)


def _item(label, route, icon='movies.png'):
    return utils.allocate_item(label,route,True,False,[],icon,{})


def _installed_ids():
    try:
        payload={'jsonrpc':'2.0','id':1,'method':'Addons.GetAddons','params':{
            'type':'xbmc.addon.video', 'enabled':True, 'properties':['name','version']}}
        data=json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
        return {a['addonid'] for a in data.get('result',{}).get('addons',[])}
    except Exception as exc:
        control.log('Simkl provider detection: %s'%exc,'warning')
        return set()


def _available(provider, installed=None):
    installed = _installed_ids() if installed is None else installed
    if provider['id'] in installed:return True
    try:
        xbmcaddon.Addon(provider['id'])
        return True
    except Exception:
        return False


def _enabled(provider):
    # Scrubs existing setting is maintained to preserve prior preferences.
    if provider['id']=='plugin.video.scrubsv2':return control.getBool('simkl.sources.scrubs')
    if provider['id']=='plugin.video.otaku':return control.getBool('simkl.sources.anime')
    return control.getBool('simkl.provider.'+provider['id'])


def _set_enabled(provider, value):
    key='simkl.sources.scrubs' if provider['id']=='plugin.video.scrubsv2' else (
        'simkl.sources.anime' if provider['id']=='plugin.video.otaku' else 'simkl.provider.'+provider['id'])
    control.setBool(key,bool(value))


def manager():
    installed=_installed_ids()
    results=[_item('Manage HTTPS direct-stream provider packs','simkl_pack_manager','search.png'),_item('Scan installed providers again','simkl_provider_manager','search.png')]
    results.append(_item('Kodi video library — %s'%('Enabled' if control.getBool('simkl.sources.local') else 'Disabled'),
                         'simkl_provider_toggle_local','movies.png'))
    for entry in PROVIDERS:
        present=_available(entry,installed)
        status=('Enabled' if _enabled(entry) else 'Disabled') if present else 'Not installed'
        # Direct plugin folder links let Kodi perform navigation itself.
        # In particular, nested ActivateWindow calls from an active plugin
        # directory handler were being swallowed when the handler returned.
        if present and _enabled(entry):
            results.append(_item('Open %s — %s'%(entry['name'],entry['kind']),
                                 'plugin://%s/'%entry['id'],'tv_shows.png'))
        results.append(_item('Configure %s — %s'%(entry['name'],status),
                             'simkl_provider_detail/'+entry['id'],'tools.png'))
    control.draw_items(results)


def detail(identifier):
    p=next((e for e in PROVIDERS if e['id']==identifier),None)
    if not p:return
    installed=_available(p)
    lines=[p['kind'], p['note'], 'Installed: %s'%('Yes' if installed else 'No'),
           'Enabled: %s'%('Yes' if _enabled(p) else 'No')]
    dialog=xbmcgui.Dialog()
    action=dialog.select(p['name'], ['Information', 'Enable / Disable'],preselect=0)
    if action==0:dialog.ok(p['name'],'\n'.join(lines))
    elif action==1:
        if not installed:dialog.ok('Simkl','Provider not installed. Install it through a trusted Kodi repository first.');return
        _set_enabled(p,not _enabled(p))
        xbmc.executebuiltin('Container.Refresh')


def toggle_local():
    control.setBool('simkl.sources.local',not control.getBool('simkl.sources.local'))
    xbmc.executebuiltin('Container.Refresh')


def launch(identifier):
    p=next((e for e in PROVIDERS if e['id']==identifier),None)
    if not p or not _enabled(p):
        xbmcgui.Dialog().ok('Simkl','This provider is disabled. Enable it in Simkl Settings > Provider Manager.')
        return
    if not _available(p):
        xbmcgui.Dialog().ok('Simkl','This provider is not installed. Please install it separately.')
        return
    # No arbitrary plugin IDs or unverified deep-link routes are accepted.
    xbmcgui.Dialog().ok('Simkl', 'Open this provider using its direct Open row in the Provider Manager. Kodi cannot reliably switch folders from this configuration action.')


def rows_for_media(media):
    installed=_installed_ids()
    rows=[]
    for p in PROVIDERS:
        if media not in p['media'] or not _enabled(p) or not _available(p,installed):continue
        rows.append(_item('Open %s to search manually — %s'%(p['name'],p['kind']),
                          'plugin://'+p['id']+'/','movies.png'))
    return rows
