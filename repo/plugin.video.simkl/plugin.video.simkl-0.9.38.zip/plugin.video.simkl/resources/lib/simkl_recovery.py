# -*- coding: utf-8 -*-
"""Crash-resistant per-device Simkl provider switches (no Kodi imports)."""
import json
import os
import tempfile
import time

DEFAULT = {'safe_mode': False, 'elementum_enabled': True, 'scrubs_enabled': True,
           'last_error': '', 'crash_count': 0, 'pending': False, 'updated': 0}


def read(profile):
    path = os.path.join(profile, 'simkl_recovery.json')
    try:
        with open(path, encoding='utf-8') as f:
            obj = json.load(f)
        if isinstance(obj, dict):
            state = dict(DEFAULT)
            for key in DEFAULT:
                if key in obj and type(obj[key]) is type(DEFAULT[key]):
                    state[key] = obj[key]
            return state
    except (OSError, ValueError, TypeError):
        pass
    return dict(DEFAULT)


def write(profile, state):
    os.makedirs(profile, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.simkl-recovery-', dir=profile)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(state, f, indent=2, sort_keys=True)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, os.path.join(profile, 'simkl_recovery.json'))
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def change(profile, **updates):
    state = read(profile)
    for key, value in updates.items():
        if key not in DEFAULT or type(value) is not type(DEFAULT[key]):
            raise ValueError('Invalid recovery setting: %s' % key)
        state[key] = value
    state['updated'] = int(time.time())
    write(profile, state)
    return state


def enabled(profile, provider):
    state = read(profile)
    if state['safe_mode']:
        return False
    return state.get(provider + '_enabled', True)


def begin(profile):
    """Detect repeated *incomplete plugin invocations*, not external APK crashes."""
    state = read(profile)
    if state['pending']:
        state['crash_count'] = min(state['crash_count'] + 1, 100)
    if state['crash_count'] >= 2:
        state['safe_mode'] = True
        state['last_error'] = 'Repeated incomplete Simkl navigation detected'
    state['pending'] = True
    write(profile, state)
    return state


def finish(profile, success=True):
    state = read(profile)
    state['pending'] = False
    if success:
        state['crash_count'] = 0
    write(profile, state)
