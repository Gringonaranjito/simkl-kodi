"""Opt-in? No: enabled built-in publicly documented Archive.org catalog adapter.

The Internet Archive is NOT a universal movie/TV stream provider. Only items
from the feature_films collection that closely match title are offered.
No torrent files, unknown redirects, or network-executable provider code.
"""
import json
import re
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen

SEARCH = 'https://archive.org/advancedsearch.php'
META = 'https://archive.org/metadata/'
VIDEO_EXT = ('.mp4', '.m4v', '.webm', '.ogv', '.ogg')
MAX_JSON = 1000000


def norm(t):
    return re.sub(r'[^a-z0-9]+',' ',str(t or '').lower()).strip()


def request_json(url):
    req=Request(url,headers={'Accept':'application/json','User-Agent':'SimklKodi/0.8.0 (personal media browser)'})
    with urlopen(req,timeout=9) as res:
        final=res.geturl()
        if not final.startswith(('https://archive.org/','https://www.archive.org/')):
            return {}
        data=res.read(MAX_JSON+1)
    if len(data)>MAX_JSON:return {}
    return json.loads(data.decode('utf-8'))


def search(title,year=None,media='movies',season=None,episode=None):
    """Return playable candidates from public domain / community Archive feature films.

    For TV episodes, no archive search for now; otherwise film/episode matches
    could be conflated and incorrectly presented as the correct episode.
    """
    if media=='shows' or not title or len(title)>160:return []
    clean_title=norm(title)
    if len(clean_title)<3:return []
    escaped=str(title).replace('"','').replace(':',' ')
    query='collection:feature_films AND mediatype:movies AND title:"%s"'%escaped
    params=[('q',query),('fl[]','identifier'),('fl[]','title'),('fl[]','year'),('rows','8'),('output','json')]
    try:
        doc=request_json(SEARCH+'?'+urlencode(params))
        rows=(doc.get('response') or {}).get('docs') or []
        output=[]
        for record in rows:
            identifier=record.get('identifier')
            if not isinstance(identifier,str) or not re.fullmatch(r'[a-zA-Z0-9_.-]{1,100}',identifier):continue
            if norm(record.get('title')) != clean_title:continue
            listed_year=str(record.get('year') or '')[:4]
            if year and listed_year.isdigit() and str(year).isdigit() and abs(int(listed_year)-int(year))>1:continue
            metadata=request_json(META+quote(identifier))
            if not isinstance(metadata,dict):continue
            meta=metadata.get('metadata') or {}
            collections=meta.get('collection') or []
            if isinstance(collections,str):collections=[collections]
            if 'feature_films' not in collections:continue
            files=metadata.get('files') or []
            count=0
            for f in files:
                filename=f.get('name') or ''
                if not isinstance(filename,str) or not filename.lower().endswith(VIDEO_EXT):continue
                if '/' in filename or '\\' in filename or filename.startswith('.'):continue
                if f.get('private')=='true' or f.get('source')=='metadata':continue
                url='https://archive.org/download/'+quote(identifier)+'/'+quote(filename)
                output.append({'url':url,'name':'Internet Archive (feature films)', 'quality':'Video file', 'language':'not verified', 'type':'direct','provider_id':'internet_archive','stream_title':filename})
                count+=1
                if count>=3:break
            if len(output)>=12:break
        return output
    except Exception as exc:
        import xbmc
        xbmc.log('Simkl Archive provider: '+str(exc),xbmc.LOGWARNING)
        return []
