"""Foreground, opt-in download of the matching Elementum package."""
import hashlib
import os
import platform
import struct
from urllib.request import urlopen, Request
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

APPROVED_VERSION = '0.1.119.1'
BASE = 'https://raw.githubusercontent.com/Gringonaranjito/simkl-kodi/main/downloads/'
PACKAGES = {
    'android-arm32': ('android_arm', 'e701ca3f6bcaedc09a81a0d711188419760e8d28631a046be63e35aa81443dbb', 36836980),
    'android-arm64': ('android_arm64', '56c710dd70349ce9b8a06c56ec4425d4014b2ae7da87e928a574efd2fd57cc64', 36027856),
    'windows-x64': ('windows_x64', '563fd9d01ffb302306835a4db6404038b1066daa65528f0c3365ccf0bb24084b', 34984145),
}

def choose(android, windows, machine, bits):
    machine = machine.lower()
    if android and machine.startswith(('arm', 'aarch64')):
        return {32:'android-arm32',64:'android-arm64'}.get(bits)
    if windows and bits == 64 and machine in ('amd64','x86_64'):
        return 'windows-x64'
    return None

def ensure():
    try:
        addon = xbmcaddon.Addon('plugin.video.elementum')
        if addon.getAddonInfo('version') in ('0.1.114.1', APPROVED_VERSION):
            remind_update_lock(addon)
        return True
    except Exception:
        pass
    dialog = xbmcgui.Dialog()
    key = choose(xbmc.getCondVisibility('System.Platform.Android'), xbmc.getCondVisibility('System.Platform.Windows'), platform.machine(), struct.calcsize('P')*8)
    if not key:
        dialog.ok('Elementum required', 'No compatible package detected. Check your Kodi architecture.\nhttps://github.com/Gringonaranjito/simkl-kodi/tree/main/downloads')
        return False
    suffix, expected, size = PACKAGES[key]
    name = 'plugin.video.elementum-%s-%s-ON-DEMAND-TEST.zip' % (APPROVED_VERSION, suffix)
    url = BASE + key + '/' + name
    if not dialog.yesno('Elementum required', 'Download Elementum for %s?\nAfter downloading, install the ZIP from Kodi Home folder. Existing add-ons will not be replaced automatically.' % key, yeslabel='Download', nolabel='Cancel'):
        return False
    path = os.path.join(xbmcvfs.translatePath('special://home/'), name)
    temp = path + '.part'
    progress = xbmcgui.DialogProgress()
    progress.create('Elementum download', key)
    try:
        digest = hashlib.sha256(); count = 0
        with urlopen(Request(url, headers={'User-Agent':'Simkl-Kodi'}), timeout=30) as response, open(temp,'wb') as out:
            while True:
                if progress.iscanceled() or xbmc.Monitor().abortRequested():
                    return False
                chunk = response.read(65536)
                if not chunk: break
                count += len(chunk)
                if count > size: raise ValueError('Unexpected package size')
                digest.update(chunk); out.write(chunk)
                progress.update(min(100, count*100//size))
        if count != size or digest.hexdigest() != expected:
            raise ValueError('Package checksum mismatch')
        os.replace(temp,path)
    except Exception as exc:
        progress.close()
        dialog.ok('Download failed', '%s\n%s' % (exc,url))
        return False
    finally:
        progress.close()
        if os.path.exists(temp): os.remove(temp)
    dialog.ok('Download complete', 'Settings > Add-ons > Install from zip file > Home folder\nSelect %s. After installing, open Elementum add-on information and turn Auto-update OFF. Then reopen Simkl. Burst may need separate installation.' % name)
    return False


def remind_update_lock(addon):
    # Kodi does not expose a supported per-addon auto-update setter to Python.
    # Do not edit Kodi's internal database or change global update preferences.
    profile = xbmcvfs.translatePath(xbmcaddon.Addon('plugin.video.simkl').getAddonInfo('profile'))
    marker = os.path.join(profile, 'elementum_update_lock_ack.txt')
    version = addon.getAddonInfo('version')
    try:
        with open(marker, 'r') as f:
            if f.read() == version:
                return
    except OSError:
        pass
    if xbmcgui.Dialog().yesno('Protect modified Elementum',
            'Turn Auto-update OFF in Elementum add-on information to prevent official updates replacing our build. Leave Simkl auto-update ON. Have you already disabled Elementum auto-updates?',
            yeslabel='Already disabled', nolabel='Not yet'):
        try:
            os.makedirs(profile, exist_ok=True)
            with open(marker, 'w') as f:
                f.write(version)
        except OSError:
            pass
