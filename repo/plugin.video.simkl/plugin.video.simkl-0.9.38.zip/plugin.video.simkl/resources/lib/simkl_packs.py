"""Non-torrent HTTPS JSON provider packs for Simkl.

Provider packs are DATA definitions, not Python scripts. They require a genuine,
trusted video-search JSON API and return direct HTTPS streams only. A pack is
not a generic web scraper and it cannot bypass site restrictions.
"""
import base64
import ipaddress
import json
import os
from urllib.parse import urlsplit, quote
import xbmc
import xbmcgui
import xbmcvfs
from resources.lib.ui import control, utils

ROOT = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.simkl/')
FILE = os.path.join(ROOT,'provider_packs.json')
FORBIDDEN = ('magnet:', '.torrent', 'btih:', 'acestream:', 'sop:')
MAX_BYTES = 120000


def valid_https(url):
    try:
        p=urlsplit(url)
        if p.scheme != 'https' or not p.hostname or p.username or p.password: return False
        if p.port not in (None, 443):return False
        host=p.hostname.strip('[]').lower()
        if host in ('localhost',) or host.endswith(('.local','.internal','.localhost')):return False
        try:
            ip=ipaddress.ip_address(host)
            if not ip.is_global:return False
        except ValueError:pass
        low=url.lower()
        return not any(x in low for x in FORBIDDEN)
    except Exception:return False


def check(pack):
    if not isinstance(pack,dict):raise ValueError('Pack must be an object')
    name=pack.get('name','')
    pid=pack.get('id','')
    api=pack.get('search_url','')
    media=pack.get('media',[])
    if not isinstance(name,str) or not (1<=len(name)<=70):raise ValueError('Invalid provider name')
    if not isinstance(pid,str) or not (1<=len(pid)<=48) or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789_-' for c in pid):raise ValueError('Invalid provider ID')
    if not isinstance(api,str) or not valid_https(api.replace('{title}','test').replace('{year}','2020').replace('{season}','1').replace('{episode}','1')):raise ValueError('Search URL must use public HTTPS')
    if not isinstance(media,list) or not media or any(x not in ('movies','shows','anime') for x in media):raise ValueError('Invalid media categories')
    if '{title}' not in api:raise ValueError('Search URL must include {title}')
    return {'id':pid,'name':name,'search_url':api,'media':media,'enabled':bool(pack.get('enabled',True))}


def load():
    try:
        if not os.path.isfile(FILE):return []
        with open(FILE,'rb') as f:data=f.read(MAX_BYTES+1)
        if len(data)>MAX_BYTES:return []
        return [check(x) for x in json.loads(data.decode('utf-8'))]
    except Exception:return []


def save(packs):
    os.makedirs(ROOT,exist_ok=True)
    with open(FILE,'w',encoding='utf-8') as f:json.dump(packs,f,indent=2)


def archive_enabled():
    try:
        with open(os.path.join(ROOT,'builtin_providers.json'),encoding='utf-8') as f:
            return bool(json.load(f).get('internet_archive', True))
    except Exception:
        return True


def toggle_archive():
    os.makedirs(ROOT,exist_ok=True)
    enabled=not archive_enabled()
    with open(os.path.join(ROOT,'builtin_providers.json'),'w',encoding='utf-8') as f:
        json.dump({'internet_archive':enabled},f)
    xbmc.executebuiltin('Container.Refresh')


def item(label,route,icon='search.png'):
    return utils.allocate_item(label,route,True,False,[],icon,{})


def manager():
    rows=[item('About JSON packs / Where to get one','simkl_pack_help'),item('Import JSON pack from an HTTPS API you trust','simkl_pack_import'),item('Create example JSON file in your Simkl profile','simkl_pack_template'),item('Refresh provider list','simkl_pack_manager')]
    rows.append(item('Internet Archive feature films — '+('Enabled' if archive_enabled() else 'Disabled'),'simkl_archive_toggle'))
    for pack in load():
        rows.append(item('%s — %s (%s)'%(pack['name'],'Enabled' if pack['enabled'] else 'Disabled',', '.join(pack['media'])),'simkl_pack_toggle/'+pack['id']))
    control.draw_items(rows)


def toggle(pid):
    packs=load()
    for pack in packs:
        if pack['id']==pid:pack['enabled']=not pack['enabled']
    save(packs)
    xbmc.executebuiltin('Container.Refresh')


def import_file():
    path=xbmcgui.Dialog().browse(1,'Select a trusted Simkl provider JSON definition','files','.json',False,False,'')
    if not path:return
    try:
        f=xbmcvfs.File(path,'r');raw=f.readBytes(MAX_BYTES+1);f.close()
        if len(raw)>MAX_BYTES:raise ValueError('File too large')
        doc=json.loads(raw.decode('utf-8'))
        new=[check(x) for x in (doc if isinstance(doc,list) else [doc])]
        old={x['id']:x for x in load()}
        for pack in new:old[pack['id']]=pack
        save(list(old.values()))
        xbmcgui.Dialog().notification('Simkl','Imported %d provider definition(s)'%len(new))
        xbmc.executebuiltin('Container.Refresh')
    except Exception as exc:xbmcgui.Dialog().ok('Simkl','Provider import rejected: '+str(exc))


def help():
    xbmcgui.Dialog().ok('Simkl Provider Packs', 'A JSON pack is NOT a list of streaming websites. It describes an HTTPS service you operate or trust that returns a JSON {streams:[{url:...}]} response. Simkl includes an Internet Archive feature-films search as an example, without requiring a JSON file. Generic Scrubs/Stremio torrent lists are not compatible. Install trusted APIs only; avoid torrent or magnet links.')


def encode(info):
    return base64.urlsafe_b64encode(json.dumps(info,separators=(',',':')).encode()).decode().rstrip('=')


def direct_sources(media,title,year='',season='',episode='',dub_only=False):
    from urllib.request import Request, urlopen
    found=[]
    for pack in load():
        if not pack['enabled'] or media not in pack['media']:continue
        if '.example' in pack['search_url'].lower() or 'your-api-host' in pack['search_url'].lower():continue
        api=pack['search_url']
        for key,val in {'title':title,'year':year,'season':season,'episode':episode}.items():api=api.replace('{'+key+'}',quote(str(val or ''),safe=''))
        if not valid_https(api):continue
        try:
            req=Request(api,headers={'Accept':'application/json','User-Agent':'Simkl-Kodi/0.7'})
            with urlopen(req,timeout=8) as response:
                if not valid_https(response.geturl()):continue
                if 'json' not in response.headers.get('Content-Type','').lower():continue
                data=response.read(MAX_BYTES+1)
            if len(data)>MAX_BYTES:continue
            doc=json.loads(data.decode('utf-8'))
            streams=doc.get('streams',[]) if isinstance(doc,dict) else []
            if not isinstance(streams,list):continue
            for source in streams[:30]:
                if not isinstance(source,dict):continue
                url=source.get('url','')
                if not isinstance(url,str) or not valid_https(url):continue
                if source.get('type','direct') not in ('direct','hls','dash'):continue
                lang=str(source.get('language','')).lower()
                if dub_only and not (source.get('dubbed') is True and lang in ('en','eng','english')):continue
                found.append({'url':url,'name':pack['name'],'quality':str(source.get('quality','unknown'))[:20],'language':lang})
        except Exception as exc:
            control.log('Simkl provider pack '+pack['id']+': '+str(exc),'warning')
    unique={}
    for source in found:unique.setdefault(source['url'],source)
    return list(unique.values())


def play(encoded):
    try:
        info=json.loads(base64.urlsafe_b64decode(encoded+'='*((-len(encoded))%4)).decode())
        url=info.get('url','')
        if not valid_https(url):raise ValueError('Invalid stream URL')
        xbmc.Player().play(url)
    except Exception as exc:xbmcgui.Dialog().ok('Simkl','Could not open direct stream: '+str(exc))


def create_template():
    template={'id':'my_licensed_video_service','name':'My licensed HTTPS video service','media':['movies','shows','anime'],'enabled':False,'search_url':'https://YOUR-API-HOST.example/search?title={title}&year={year}&season={season}&episode={episode}'}
    os.makedirs(ROOT,exist_ok=True)
    path=os.path.join(ROOT,'provider-pack-EXAMPLE.json')
    with open(path,'w',encoding='utf-8') as f:json.dump(template,f,indent=2)
    xbmcgui.Dialog().ok('Simkl','Example created at: '+path+'\n\nThis is only a template. Replace YOUR-API-HOST with an actual HTTPS service that returns a JSON streams array before importing it. It is not a working provider.')
