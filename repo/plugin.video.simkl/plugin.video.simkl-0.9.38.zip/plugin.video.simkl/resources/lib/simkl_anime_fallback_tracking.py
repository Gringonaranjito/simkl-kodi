"""Conservative anime Elementum fallback tracking (no playback commands)."""
import json, os, re, time
from resources.lib.ui import control

def _path():
    os.makedirs(control.dataPath,exist_ok=True)
    return os.path.join(control.dataPath,'simkl_anime_fallback_pending.json')

def arm_anime(mal_id, episode, title):
    data={'mal':int(mal_id),'episode':int(episode),'title':str(title), 'armed':time.time(),
          'sent':False,'started':False}
    with open(_path(),'w',encoding='utf-8') as f:json.dump(data,f)

def _read():
    try:
        with open(_path(),encoding='utf-8') as f:return json.load(f)
    except (ValueError,OSError):return {}

def _write(data):
    with open(_path(),'w',encoding='utf-8') as f:json.dump(data,f)

def _norm(v):return re.sub(r'[^a-z0-9]+','',str(v or '').lower())

def poll():
    data=_read()
    if not data or data.get('sent') or time.time()-float(data.get('armed') or 0)>45*60:return
    from resources.lib.simkl_playback_tracking import _playing_metadata,_elementum_playing
    playback=_playing_metadata()
    if not playback:return
    item,properties=playback
    if not _elementum_playing(item):return
    label=' '.join([str(item.get('title') or ''),str(item.get('file') or '').rsplit('/',1)[-1]])
    if _norm(data['title']) not in _norm(label):return
    numbers={int(x) for x in re.findall(r'(?i)(?:\bE(?:P)?[ ._-]*|\bepisode[ ._-]*)(\d{1,3})\b',label)}
    if len(numbers)!=1 or data['episode'] not in numbers:return
    pct=float(properties.get('percentage') or 0)
    if pct<80 or pct>100:return
    # Look up the real Simkl anime identity from the MAL ID. Never send MAL as simkl.
    try:
        from resources.lib.simkl_media import _call,_post
        response=_call('/search/id',{'mal':str(data['mal'])})
        matches=response if isinstance(response,list) else [response]
        anime=[r for r in matches if isinstance(r,dict) and str(r.get('type') or '').lower()=='anime']
        if len(anime)!=1 or not str((anime[0].get('ids') or {}).get('simkl') or '').isdigit():
            raise ValueError('Could not resolve an unambiguous Simkl anime ID')
        simkl=int(anime[0]['ids']['simkl'])
        data['sent']=True
        _write(data)
        _post('/sync/history',{'anime':[{'ids':{'simkl':simkl},'episodes':[{'number':data['episode']}]}]})
        control.notify('Simkl — Anime Completed', '%s episode %d — %.0f%% watched' %
                       (data['title'],data['episode'],pct))
        control.log('Simkl anime fallback 80%% sync accepted MAL %s episode %s' %
                    (data['mal'],data['episode']),'info')
    except Exception as exc:
        control.log('Simkl anime fallback completion skipped: %s' % exc,'warning')
