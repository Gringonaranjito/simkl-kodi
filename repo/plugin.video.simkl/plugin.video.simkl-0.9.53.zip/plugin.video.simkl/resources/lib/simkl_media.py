"""Simkl watchlists for movies and TV; direct-file playback helpers.

Elementum movie and TV-episode source browsing; anime stays Otaku-based by default.
Scrubs V2 is a separate user-installed fallback, not a scraper integrated in Simkl.
"""
import json
import re
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import defaultdict
from urllib.parse import quote, urlencode

from resources.lib.ui import control, client, utils

STATUSES = [('Currently Watching','watching'), ('Completed','completed'),
            ('On Hold','hold'), ('Dropped','dropped'),
            ('Plan to Watch','plantowatch'), ('All Titles','all')]


def statuses_for(media):
    return [(label, value) for label, value in STATUSES
            if media != 'movies' or value != 'watching']


def _headers():
    from resources.lib.WatchlistFlavor.Simkl import SimklWLF
    token = control.getSetting('simkl.token')
    if not token:
        return None
    return {'Authorization':'Bearer '+token,
            'simkl-api-key':SimklWLF.client_id,
            'User-Agent':'Simkl-Kodi/0.5.0',
            'Content-Type':'application/json'}


def _call(path,params=None):
    headers=_headers()
    if not headers: raise ValueError('Sign in through Settings > Watchlist > Simkl')
    url='https://api.simkl.com'+path
    resp=client.get(url, headers=headers, params=params or {})
    if not resp: raise ValueError('Simkl did not return a response')
    data=resp.json()
    if not isinstance(data,(list,dict)): raise ValueError('Unexpected Simkl response')
    return data


def _msg(text):control.ok_dialog(control.ADDON_NAME,text)


def _item(label,url,icon='movies.png',info=None,cm=None):
    return utils.allocate_item(label,url,True,False,cm or [],icon,info or {})


def _simkl_art(path, category, size):
    """Build an image URL only from a supported Simkl relative image path.

    https://api.simkl.org/conventions/images
    """
    if not isinstance(path, str) or not re.fullmatch(r'[A-Za-z0-9/_-]+', path):
        return None
    # The API returns paths, not complete URLs. Never interpolate a remote URL.
    return 'https://wsrv.nl/?url=https://simkl.in/%s/%s%s.webp&q=90' % (category,path,size)


def _movie_synopses(rows):
    """Obtain descriptions from Simkl; fall back to TMDb by verified movie ID.

    Watchlist responses often omit overviews. Do not treat an empty Simkl
    description as final when a matching TMDb ID can supply one. Cache only
    public descriptions; empty results are retried on a shorter schedule.
    """
    try:
        import xbmcaddon
        import xbmcvfs
        profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        os.makedirs(profile, exist_ok=True)
        cache_path = os.path.join(profile, 'simkl_movie_synopsis_cache.json')
    except Exception:
        cache_path = None
    try:
        with open(cache_path, 'r', encoding='utf-8') as handle:
            cache = json.load(handle)
        if not isinstance(cache, dict):
            cache = {}
    except Exception:
        cache = {}

    try:
        from resources.lib.endpoints import tmdb
        tmdb_key = tmdb.apiKey
    except Exception:
        tmdb_key = None

    now = time.time()
    results = {}
    missing = []
    for row in rows:
        rec = row.get('movie') or {}
        ids = rec.get('ids') or {}
        sid = str(ids.get('simkl') or '')
        if not sid:
            continue
        supplied = (rec.get('overview') or rec.get('description') or
                    row.get('overview') or row.get('description'))
        if isinstance(supplied, str) and supplied.strip():
            results[sid] = supplied.strip()
            continue
        saved = cache.get(sid)
        if isinstance(saved, dict):
            cached_text = saved.get('text') or ''
            if isinstance(cached_text, str) and cached_text.strip():
                # Existing descriptions remain reusable, including v0.9.24 cache.
                if now - saved.get('at', 0) < 1209600:
                    results[sid] = cached_text.strip()
                    continue
            # Even older empty cache entries are eligible for fallback now.
            elif saved.get('fallback_checked') and now - saved.get('at', 0) < 86400:
                continue
        tmdb_id = str(ids.get('tmdb') or '')
        missing.append((sid, tmdb_id if tmdb_id.isdigit() and int(tmdb_id) > 0 else None))

    def fetch(sid, tmdb_id):
        description = ''
        try:
            data = _call('/movies/%s' % int(sid))
            if isinstance(data, dict):
                value = data.get('overview') or data.get('description') or data.get('plot') or ''
                if isinstance(value, str):
                    description = value.strip()
        except Exception as exc:
            control.log('Simkl movie synopsis lookup failed for %s: %s' % (sid, exc), 'warning')
        if not description and tmdb_id and tmdb_key:
            try:
                from resources.lib.endpoints import tmdb
                response = client.get(
                    tmdb.baseUrl + 'movie/' + tmdb_id,
                    params={'api_key': tmdb_key, 'language': 'en-US'})
                data = control.safe_json(response) or {}
                if isinstance(data, dict):
                    value = data.get('overview') or ''
                    if isinstance(value, str):
                        description = value.strip()
            except Exception as exc:
                control.log('TMDb movie synopsis lookup failed for %s: %s' % (tmdb_id, exc), 'warning')
        return sid, description

    if missing:
        with ThreadPoolExecutor(max_workers=4) as pool:
            futures = [pool.submit(fetch, sid, tid) for sid, tid in missing[:36]]
            for future in as_completed(futures):
                sid, description = future.result()
                cache[sid] = {'text': description, 'at': now,
                              'fallback_checked': True}
                if description:
                    results[sid] = description
        if cache_path:
            try:
                temp_path = cache_path + '.tmp'
                with open(temp_path, 'w', encoding='utf-8') as handle:
                    json.dump(cache, handle, ensure_ascii=False)
                os.replace(temp_path, cache_path)
            except Exception as exc:
                control.log('Simkl synopsis cache write skipped: %s' % exc, 'warning')
    return results


def _show_metadata(rec, row, display_title, year, progress_plot, media="shows"):
    """Metadata sent to Kodi's InfoTagVideo and ListItem artwork fields."""
    raw_desc = (rec.get('overview') or rec.get('description') or
                row.get('overview') or row.get('description') or '')
    desc = raw_desc.strip() if isinstance(raw_desc, str) else ''
    genres = rec.get('genres') or []
    if isinstance(genres,str):genres=[x.strip() for x in genres.split(',') if x.strip()]
    genres = [str(g) for g in genres if g]
    info = {'title':display_title,'year':year or 0,
            'mediatype':'movie' if media == 'movies' else 'tvshow',
            'plot':desc or progress_plot}
    if genres:info['genre']=genres
    if media == 'movies':
        # Details are shown in Kodi's Information panel, when supplied by Simkl.
        released = rec.get('released') or rec.get('release_date')
        if isinstance(released, str) and re.fullmatch(r'\d{4}-\d{2}-\d{2}', released):
            info['premiered'] = released
        runtime = rec.get('runtime') or rec.get('duration')
        if isinstance(runtime, (int, float)) and runtime > 0:
            info['duration'] = int(runtime) * 60
    rating = rec.get('ratings') or rec.get('rating') or {}
    if isinstance(rating,(int,float)) and rating>0:info['rating']=rating
    ids = rec.get('ids') or {}
    uid = {k:str(ids[k]) for k in ('imdb','tmdb','tvdb') if ids.get(k)}
    if uid:info['UniqueIDs']=uid
    poster=_simkl_art(rec.get('poster'), 'posters', '_m')
    fanart=_simkl_art(rec.get('fanart'), 'fanart', '_mobile')
    return info, poster, fanart


def _movie_actions():
    # Movie history actions are deliberately not duplicated: the status menu
    # is the sole manual movie list control. Episode history remains separate.
    return [('Change Simkl watchlist status', 'simkl_action_status'),
            ('Reset Resume Time', 'simkl_action_reset_resume')]


def _episode_actions():
    return [('Mark episode watched in Simkl', 'simkl_action_watched'),
            ('Reset Resume Time', 'simkl_action_reset_resume')]



def draw_movie_provider_picker():
    """Restore provider-first Movies navigation, matching existing TV navigation."""
    from resources.lib import simkl_recovery as recovery
    rows = []
    if recovery.enabled(control.dataPath, 'scrubs'):
        rows.append(_item('Scrubs V2 — Movies', 'simkl_movie_provider/scrubs', 'movies.png'))
    if recovery.enabled(control.dataPath, 'elementum'):
        rows.append(_item('Elementum — Movies', 'simkl_movie_provider/elementum', 'movies.png'))
    rows.append(_item('Diagnostics & Recovery', 'simkl_recovery', 'tools.png'))
    control.draw_items(rows)


def draw_scrubs_movie_handoff(simkl_id):
    """Preserve title context but don't invent undocumented Scrubs playback URLs."""
    try:
        rec = _call('/movies/%s' % int(simkl_id))
        title = rec.get('title') or 'this title'
    except Exception:
        title = 'this title'
    control.draw_items([
        _item('Search %s in Scrubs V2' % title,
              'plugin://plugin.video.scrubsv2/', 'movies.png',
              {'title': title, 'plot': 'Open Scrubs V2 and search for this movie.'}),
    ])


def draw_tv_provider_picker():
    """Choose a TV provider before navigating Simkl watchlist categories."""
    from resources.lib import simkl_recovery as recovery
    items = []
    if recovery.enabled(control.dataPath, 'elementum'):
        items.append(_item('Elementum — TV shows', 'simkl_tv_provider/elementum', 'tv_shows.png'))
    if recovery.enabled(control.dataPath, 'scrubs'):
        items.append(_item('Scrubs V2 — TV shows', 'simkl_tv_provider/scrubs', 'tv_shows.png'))
    items.append(_item('Diagnostics & Recovery', 'simkl_recovery', 'tools.png'))
    control.draw_items(items)


def _show_provider_url(provider, record):
    """Construct a native provider show-seasons URL using Simkl's title metadata.

    Don't start a player or busy dialog while Kodi is building the folder.
    Missing provider IDs fall back to Simkl's own episode browser.
    """
    ids = record.get('ids') or {}
    if provider == 'elementum':
        tmdb = ids.get('tmdb')
        if str(tmdb or '').isdigit():
            return 'plugin://plugin.video.elementum/show/%s/seasons' % int(tmdb)
        return None
    if provider == 'scrubs':
        title = str(record.get('title') or '').strip()
        if not title:
            return None
        params = {'action': 'seasons', 'tvshowtitle': title,
                  'year': str(record.get('year') or ''),
                  'imdb': str(ids.get('imdb') or ''),
                  'tvdb': str(ids.get('tvdb') or ''),
                  'tmdb': str(ids.get('tmdb') or '')}
        return 'plugin://plugin.video.scrubsv2/?' + urlencode(params)
    return None


def draw_statuses(media, provider=None):
    if not _headers():
        _msg('Connect your account in Settings > Watchlist > Simkl.')
        return
    if media in ('shows', 'movies') and provider not in ('elementum', 'scrubs', None):
        _msg('Unknown playback provider selected.')
        return
    if media in ('shows', 'movies') and provider:
        from resources.lib import simkl_recovery as recovery
        if not recovery.enabled(control.dataPath, provider):
            _msg('%s is disabled in Simkl Diagnostics & Recovery.' % provider.title())
            return
        if provider == 'elementum':
            from resources.lib.simkl_elementum_install import ensure
            if not ensure():
                control.draw_items([])
                return
        try:
            import xbmcaddon
            xbmcaddon.Addon('plugin.video.elementum' if provider == 'elementum' else 'plugin.video.scrubsv2')
        except Exception:
            _msg('%s is not installed on this device.' % provider.title())
            return
    if provider == "elementum":
        from resources.lib.simkl_elementum_start import request_engine
        request_engine()
    statuses = statuses_for(media)
    entries = []
    for title, status in statuses:
        suffix = '/%s' % provider if provider else ''
        entries.append(_item(title, 'simkl_media_list/%s/%s%s' % (media, status, suffix),
                             'tv_shows.png' if media == 'shows' else 'movies.png'))
    control.draw_items(entries)


def _folder_marker(total, watched, partial, completed=False):
    total = max(int(total or 0), int(watched)+int(partial), 1)
    if completed:
        watched, partial = total, 0
    return {'playcount':int(watched >= total), 'simkl_folder_counts':
            {'totalepisodes':str(total), 'watchedepisodes':str(watched), 'inprogressepisodes':str(partial)}}


def _tv_cloud_records():
    from resources.lib.simkl_drive import refresh as drive_refresh
    from resources.lib.simkl_cloud_resume import refresh as simkl_refresh
    records = dict(simkl_refresh().get('records', {}))
    for key, value in drive_refresh().items():
        if value.get('updated',0) >= records.get(key,{}).get('updated',0):
            records[key] = value
    return records


def _tv_progress_sets(sid, cloud):
    import os
    from resources.lib.simkl_episode_tracking import watched_set, _file, _load
    watched = watched_set(sid)
    prefix = 'episode:%s:' % int(sid)
    records = {k:v for k,v in cloud.items() if k.startswith(prefix)}
    folder = os.path.dirname(_file('recent_shows.json'))
    for name in os.listdir(folder):
        match = re.fullmatch(r'progress-%s-(\d+)-(\d+)\.json' % int(sid), name)
        if match:
            key = prefix + '%d:%d' % tuple(map(int,match.groups()))
            value = _load(os.path.join(folder,name))
            if value.get('updated',0) >= records.get(key,{}).get('updated',0):
                records[key] = value
    partial = set()
    for key,value in records.items():
        try: pair = tuple(map(int,key.split(':')[2:]))
        except ValueError: continue
        if len(pair)!=2: continue
        if value.get('completed') or value.get('finished'): watched.add(pair)
        elif not value.get('reset') and 0<float(value.get('percentage') or 0)<80: partial.add(pair)
    return watched, partial-watched


def _history_pairs(row):
    """Explicit episode history only; never infer episode numbers from counts."""
    result = set()
    for season in row.get('seasons') or []:
        if not isinstance(season, dict): continue
        for ep in season.get('episodes') or []:
            if not isinstance(ep, dict): continue
            try:
                if ep.get('watched') is False or ep.get('watched_at') is False: continue
                n = int(season.get('number', season.get('season')))
                e = int(ep.get('number', ep.get('episode')))
                if n >= 0 and e > 0: result.add((n,e))
            except (ValueError, TypeError): continue
    return result


def _tv_history_row(sid):
    # Fetch authenticated history, not the public episode catalogue.
    try:
        data = _call('/sync/all-items/shows', {'extended':'full','episode_watched_at':'yes','include_all_episodes':'yes'})
        for row in data.get('shows', []):
            if str((row.get('show') or {}).get('ids',{}).get('simkl')) == str(sid):
                control.log('Simkl TV history ID %s: reported=%s, explicit=%d' % (sid,row.get('watched_episodes_count'),len(_history_pairs(row))), 'warning')
                return row
        control.log('Simkl TV history ID %s not present in response' % sid, 'warning')
    except Exception as exc:
        control.log('Simkl TV history unavailable: %s' % exc, 'warning')
    return {}


def _tv_details(sid, row):
    rec = dict(row.get('show') or {})
    try:
        detail = _call('/tv/%s' % int(sid))
        if isinstance(detail, dict): rec.update({k:v for k,v in detail.items() if v})
    except Exception as exc:
        control.log('Simkl TV details unavailable: %s' % exc, 'warning')
    return rec


def _show_progress_marker(sid, row, status, cloud):
    watched, partial = _tv_progress_sets(sid, cloud)
    watched.update(_history_pairs(row))
    partial -= watched
    done = max(len(watched), int(row.get('watched_episodes_count') or row.get('watched_episodes') or 0))
    total = int(row.get('total_episodes_count') or row.get('total_episodes') or 0)
    completed = row.get('status') == 'completed' or status == 'completed'
    # Unknown totals must never turn a partially watched show into a completed one.
    if not total: total = done + len(partial) + 1
    return _folder_marker(total,done,len(partial),completed)


def draw_list(media, status, provider=None):
    # Old Kodi history or favourites may still reference this removed list.
    if media == 'movies' and status == 'watching':
        status = 'plantowatch'
    if media == 'movies' and status in ('completed','hold','dropped','plantowatch','all'):
        import xbmcgui
        xbmcgui.Window(10000).setProperty('simkl.last.movie.status', status)
    try:
        data = _call('/sync/all-items/%s/%s' % (media, status), {'extended':'full','language':'en', **({'episode_watched_at':'yes','include_all_episodes':'yes'} if media == 'shows' else {})})
        rows = data.get(media, [])
        output = []
        movie_synopses = _movie_synopses(rows) if media == 'movies' else {}
        if media == 'shows':
            try:
                from resources.lib.simkl_episode_tracking import remember_shows
                remember_shows([r.get('show') or {} for r in rows])
            except Exception as exc:
                control.log('Simkl TV index unavailable: %s' % exc, 'warning')
        cloud_records = _tv_cloud_records() if media == 'shows' else {}
        for row in rows:
            rec = row.get('show', {}) if media == 'shows' else row.get('movie', {})
            ids = rec.get('ids') or {}
            sid = ids.get('simkl')
            if not sid:
                continue
            title = rec.get('title') or row.get('title') or 'Untitled'
            year = rec.get('year')
            label = '%s (%s)' % (title, year) if year else title
            display_title = title
            progress_plot = title
            if media == 'movies' and status != 'completed':
                try:
                    from resources.lib.simkl_resume import resume_data
                    saved = resume_data(sid)
                    if not saved.get('finished') and 0 < float(saved.get('percentage') or 0) < 80:
                        percentage = int(round(float(saved['percentage'])))
                        prefix = '%d%% watched — ' % percentage
                        label = prefix + label
                        display_title = prefix + title
                        progress_plot = 'Partially watched: %d%%. Open to continue watching.\n%s' % (percentage, title)
                except Exception as exc:
                    control.log('Simkl partial marker unavailable for %s: %s' % (sid, exc), 'warning')
            if media == 'shows':
                next_ep = row.get('next_to_watch') or row.get('next_watch_info') or {}
                if isinstance(next_ep, dict):
                    ns, ne = next_ep.get('season'), next_ep.get('episode', next_ep.get('number'))
                    if ns is not None and ne is not None: progress_plot = 'Next episode: S%sE%s' % (ns,ne)
                elif isinstance(next_ep, str) and re.fullmatch(r'S\d+E\d+', next_ep, re.I):
                    progress_plot = 'Next episode: ' + next_ep
                marker = _show_progress_marker(sid, row, status, cloud_records)
            url = 'simkl_media_detail/%s/%s' % (media, sid)
            if media == 'shows' and provider:
                url = ('simkl_media_detail/shows/%s/elementum' % sid if provider == 'elementum' else _show_provider_url(provider, rec)) or url
            elif media == 'movies' and provider == 'scrubs':
                url = 'simkl_movie_scrubs/%s' % sid
            elif media == 'movies' and provider == 'elementum':
                tmdb_id = ids.get('tmdb')
                if str(tmdb_id or '').isdigit() and int(tmdb_id) > 0:
                    url = 'simkl_resume_choices/%s' % sid
                # Missing TMDb ID falls back to the existing movie detail flow.
            if media == 'shows':
                info, poster, fanart = _show_metadata(rec, row, display_title, year, progress_plot)
                info.update(marker)
                if progress_plot != title: info['plot'] = progress_plot + '\n\n' + (info.get('plot') or title)
                # Preserve the provider-first direct show link. Only the Kodi
                # label/artwork/info fields change, not the navigation route.
                output.append(utils.allocate_item(label, url, True, False, [('WatchList Manager', 'simkl_action_status', 'simkl_media_detail/shows/%s' % sid)],
                    poster or 'tv_shows.png', info, fanart=fanart, poster=poster))
            else:
                info, poster, fanart = _show_metadata(
                    rec, row, display_title, year, progress_plot, media='movies')
                if status != 'completed' and display_title != title:
                    info['simkl_resume_seconds'] = saved.get('seconds',0)
                    info['simkl_resume_total'] = saved.get('total',0)
                synopsis = movie_synopses.get(str(sid))
                if synopsis:
                    info['plot'] = synopsis
                    info['plotoutline'] = synopsis
                output.append(utils.allocate_item(
                    label, url, True, False, _movie_actions(),
                    poster or 'movies.png', info, fanart=fanart, poster=poster))
        control.draw_items(output, 'tvshows' if media == 'shows' else 'videos', cache_to_disc=media != 'shows')
        if not output:
            _msg('No titles in this Simkl category.')
    except Exception as exc:
        control.log('Simkl list read failed: %s' % exc, 'warning')
        _msg('Could not load this Simkl list: %s' % exc)


def draw_detail(media,simkl_id,provider=None):
    if media=='shows':
        try:
            data=_call('/tv/episodes/%s'%simkl_id)
            episodes=data if isinstance(data,list) else data.get('episodes',[])
            grouped=defaultdict(list)
            for ep in episodes:
                if ep.get('type')=='special': continue
                season=ep.get('season')
                if season is not None: grouped[int(season)].append(ep)
            if not grouped:
                _msg('No seasons returned by Simkl.');return
            cloud = _tv_cloud_records()
            watched, partial = _tv_progress_sets(simkl_id, cloud)
            row = _tv_history_row(simkl_id)
            watched.update(_history_pairs(row))
            rec = _tv_details(simkl_id, row)
            title = rec.get('title') or 'TV Show'
            meta, poster, fanart = _show_metadata(rec,row,title,rec.get('year'),title)
            out = []
            for n in sorted(grouped):
                keys = {(n, int(ep.get('episode') or 0)) for ep in grouped[n] if ep.get('episode')}
                done = {k for k in keys if k in watched}
                done.update((n,int(ep['episode'])) for ep in grouped[n] if ep.get('episode') and (ep.get('watched_at') or ep.get('last_watched_at')))
                info = {'title':'%s — Season %d' % (title,n), 'tvshowtitle':title, 'mediatype':'season', 'season':n, 'plot':'%d of %d episodes watched. %d in progress.\n\n%s' % (len(done),len(keys),len((keys & partial)-done),meta.get('plot') or title)}
                info.update(_folder_marker(len(keys),len(done),len((keys & partial)-done)))
                out.append(utils.allocate_item('Season %d (%d episodes)'%(n,len(grouped[n])),
                    'simkl_media_season/%s/%s%s'%(simkl_id,n,'/elementum' if provider=='elementum' else ''),True,False,[],poster or 'tv_shows.png',info,poster=poster,fanart=fanart))
            control.draw_items(out, 'seasons', cache_to_disc=False)
        except Exception as exc:
            control.log('Simkl TV episode lookup failed: %s'%exc,'warning')
            _msg('Could not load TV seasons: %s'%exc)
    else:
        rows = []
        try:
            from resources.lib.simkl_resume import resume_data
            progress = resume_data(simkl_id)
            pct = float(progress.get('percentage') or 0)
            if 0 < pct < 80:
                rows.append(_item('Continue Watching — %d%% (resume options)' % int(pct),
                                  'simkl_resume_choices/%s' % simkl_id, 'movies.png',
                                  cm=[('Reset Resume Time', 'simkl_action_reset_resume')]))
        except Exception as exc:
            control.log('Simkl resume menu unavailable: %s' % exc, 'warning')
        rows.append(_item('Find playback options (right-click for Simkl actions)',
                          'simkl_media_sources/movies/%s/0/0'%simkl_id, cm=_movie_actions()))
        control.draw_items(rows)


def draw_season(simkl_id,season,provider=None):
    try:
        data=_call('/tv/episodes/%s'%simkl_id)
        eps=data if isinstance(data,list) else data.get('episodes',[])
        row = _tv_history_row(simkl_id)
        rec = _tv_details(simkl_id,row)
        title = rec.get('title') or 'TV Show'
        history, _ = _tv_progress_sets(simkl_id,_tv_cloud_records())
        history.update(_history_pairs(row))
        _, poster, fanart = _show_metadata(rec,row,title,rec.get('year'),title)
        out=[]
        for ep in sorted(eps,key=lambda e:int(e.get('episode') or 0)):
            if ep.get('type')=='special' or int(ep.get('season') or -1)!=int(season): continue
            number=int(ep.get('episode') or 0)
            name=ep.get('title') or 'Episode %d'%number
            label='%02d. %s'%(number,name)
            watched = False
            progress = {}
            try:
                from resources.lib.simkl_episode_tracking import watched_set, bookmark
                progress = bookmark(simkl_id,season,number)
                watched = bool((int(season),number) in history or ep.get('watched_at') or ep.get('last_watched_at') or progress.get('completed'))
                # Native Kodi playcount and resume state render the status icon.
                if progress.get('reset') or progress.get('finished') or not 0<float(progress.get('percentage') or 0)<80:
                    progress = {}
            except Exception as exc:
                control.log('Simkl episode marker unavailable: %s' % exc,'warning')
            out.append(_item(label,('simkl_tv_episode/%s/%s/%s' if provider=='elementum' else 'simkl_media_sources/shows/%s/%s/%s')%(simkl_id,season,number),'tv_shows.png',
                             {'title':name,'tvshowtitle':title,'mediatype':'episode','playcount':int(watched),'season':int(season),'episode':number,'plot':'%s — Season %s, Episode %s\n%s\n\n%s' % (title,season,number,'Watched' if watched else 'In progress' if progress else 'Unwatched',ep.get('description') or name),'simkl_resume_seconds':0 if watched else progress.get('seconds',0),'simkl_resume_total':progress.get('total',0)},
                             cm=_episode_actions()))
        control.draw_items(out,'episodes', cache_to_disc=False)
        if not out:_msg('No episodes in this season.')
    except Exception as exc:
        _msg('Could not load TV episodes: %s'%exc)


def _jsonrpc(method,params):
    import xbmc
    payload={'jsonrpc':'2.0','id':1,'method':method,'params':params}
    result=json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
    return result.get('result') or {}


def _normalize(title):
    import re
    return re.sub(r'[^a-z0-9]', '', (title or '').lower())


def _local_candidates(media, simkl_id, season, episode):
    if not control.getBool('simkl.sources.local'):
        return []
    # Match exact title; never present a different film or show as a source.
    try:
        details = _call('/movies/%s' % simkl_id if media == 'movies' else '/tv/%s' % simkl_id)
        title = details.get('title') or ''
        if not title:
            return []
        year = details.get('year')
        results = []
        if media == 'movies':
            library = _jsonrpc('VideoLibrary.GetMovies', {
                'properties': ['title', 'year', 'file'], 'limits': {'start': 0, 'end': 5000}})
            for movie in library.get('movies') or []:
                if _normalize(movie.get('title')) != _normalize(title):
                    continue
                if year and movie.get('year') and abs(int(movie['year']) - int(year)) > 1:
                    continue
                results.append(('Kodi Library: %s (%s)' % (title, movie.get('year') or ''),
                                'simkl_local_play/movie/%s' % movie['movieid']))
        else:
            library = _jsonrpc('VideoLibrary.GetEpisodes', {
                'properties': ['title', 'showtitle', 'season', 'episode', 'file'],
                'limits': {'start': 0, 'end': 10000}})
            for item in library.get('episodes') or []:
                if _normalize(item.get('showtitle')) != _normalize(title):
                    continue
                if int(item.get('season', -1)) != int(season) or int(item.get('episode', -1)) != int(episode):
                    continue
                results.append(('Kodi Library: %s S%02dE%02d' % (title, int(season), int(episode)),
                                'simkl_local_play/episode/%s' % item['episodeid']))
        return results
    except Exception as exc:
        control.log('Simkl library search failed: %s' % exc, 'warning')
        return []


def draw_sources(media, simkl_id, season, episode):
    """Search local library and configured HTTPS direct-stream provider packs.

    External Kodi add-ons remain separate browser handoffs, never fake hits.
    """
    from resources.lib.simkl_providers import rows_for_media
    from resources.lib.simkl_packs import direct_sources, encode
    rows=[]
    for title,path in _local_candidates(media,simkl_id,season,episode):
        rows.append(_item(title,path,'movies.png'))
    try:
        details=_call('/movies/%s'%simkl_id if media=='movies' else '/tv/%s'%simkl_id)
        title=details.get('title') or ''
        if title:
            genres=[str(g).lower() for g in (details.get('genres') or [])]
            anime_like=media=='anime' or 'anime' in genres or 'animation' in genres
            strict=anime_like and control.getBool('divflavors.dubonly')
            results=direct_sources(media,title,details.get('year'),season,episode,strict)
            # Built-in classic/public-domain movie archive search. This cannot
            # supply modern licensed movies or TV episodes.
            if media=='movies' and not strict:
                from resources.lib.simkl_packs import archive_enabled
                if archive_enabled():
                    from resources.lib.simkl_archive import search as archive_search
                    results.extend(archive_search(title, details.get('year'), media, season, episode))
            seen=set()
            for source in results:
                if source['url'] in seen:continue
                seen.add(source['url'])
                label='%s — %s — %s'%(source['name'],source['quality'],source['language'] or 'Audio unspecified')
                if source.get('stream_title'):label += ' — '+source['stream_title'][:60]
                rows.append(_item(label,'simkl_stream_play/'+encode(source),'movies.png'))
    except Exception as exc:
        control.log('Simkl pack search: %s'%exc,'warning')
    from resources.lib import simkl_recovery as recovery
    if recovery.enabled(control.dataPath, 'elementum'):
        rows.extend([_item(label,path,'movies.png') for label,path in _elementum_option(media, simkl_id, season, episode)])
    # Never run modal watched/status actions as Kodi folder navigation: the
    # v0.9.0 crash log included a concurrent-busydialog fatal exit.
    rows.append(_item('Simkl actions: right-click / long-press title or episode',
                      'simkl_action_help', 'tools.png'))
    rows.extend(rows_for_media(media))
    rows.append(_item('Find / import direct-stream providers','simkl_pack_manager','search.png'))
    if control.getBool('simkl.sources.local'):
        rows.append(_item('Browse Kodi video library','simkl_local','movies.png'))
    control.draw_items(rows)

def play_local(kind, item_id):
    import xbmc
    key = 'movieid' if kind == 'movie' else 'episodeid'
    try:
        response = _jsonrpc('Player.Open', {'item': {key: int(item_id)}})
        if 'error' in response:
            raise ValueError(response['error'])
    except Exception as exc:
        control.log('Simkl local playback failed: %s' % exc, 'warning')
        _msg('Kodi could not open the selected library item: %s' % exc)


def launch_target(which):
    import xbmc
    try:
        if which=='scrubs':
            if not control.getBool('simkl.sources.scrubs'):return
            import xbmcaddon
            try:xbmcaddon.Addon('plugin.video.scrubsv2')
            except Exception:
                _msg('Scrubs V2 is not installed. Install it separately before using this option.');return
            xbmcgui.Dialog().ok('Simkl', 'Open Scrubs using the direct folder link in the Provider Manager.')
        elif which=='local':
            xbmc.executebuiltin('ActivateWindow(Videos,videodb://,return)')
        elif which=='anime_search':
            xbmc.executebuiltin('ActivateWindow(Videos,plugin://plugin.video.simkl/search,return)')
    except Exception as exc:
        control.log('Simkl playback handoff failed: %s'%exc,'warning')
        _msg('Could not open playback add-on: %s'%exc)


# Simkl status and watched-history operations. No write is made without a
# deliberate action; a source-search result is not evidence that it played.
def _post(path, payload):
    headers = _headers()
    if not headers:
        raise ValueError('Sign in through Settings > Watchlist > Simkl')
    response = client.post('https://api.simkl.com' + path, headers=headers, json_data=payload)
    if response is None or not (200 <= getattr(response, 'status_code', 0) < 300):
        raise RuntimeError('Simkl API did not accept the update')
    data = response.json()
    if not isinstance(data, dict):
        raise RuntimeError('Invalid Simkl update response')
    not_found = data.get('not_found') or {}
    if not isinstance(not_found, dict):
        raise RuntimeError('Unexpected Simkl response')
    if any(not_found.get(k) for k in ('movies', 'shows', 'episodes')):
        raise RuntimeError('Simkl could not match the selected title or episode')
    # A 2xx acknowledgement with no not_found entries is accepted, even when
    # `added` counts are zero (already present / unchanged). Verify list separately.
    return data


def promote_planned_title(media, simkl_id):
    """Promote only a currently planned TV show after playback."""
    if media == 'movies':
        return False
    if media != 'shows' or not str(simkl_id).isdigit():
        raise ValueError('Invalid playback identity')
    data = _call('/sync/all-items/%s/plantowatch' % media)
    if not isinstance(data, dict) or not isinstance(data.get(media), list):
        raise RuntimeError('Unable to verify planned watchlist')
    key = 'show'
    if not any(str(((row.get(key) or {}).get('ids') or {}).get('simkl')) == str(simkl_id)
               for row in data[media] if isinstance(row, dict)):
        return False
    _post('/sync/add-to-list', {media: [{'ids': {'simkl': int(simkl_id)}, 'to': 'watching'}]})
    control.log('Simkl moved %s %s to Currently Watching' % (media, simkl_id), 'info')
    return True


def mark_watched(media, simkl_id, season, episode):
    import xbmcgui
    media = str(media)
    if media not in ('movies', 'shows') or not str(simkl_id).isdigit():
        return
    if media == 'shows' and (not str(season).isdigit() or not str(episode).isdigit() or int(episode) < 1):
        return
    what = 'movie' if media == 'movies' else 'episode S%02dE%02d' % (int(season),int(episode))
    if not xbmcgui.Dialog().yesno('Simkl', 'Mark this %s as watched on your Simkl account?' % what):
        return
    ids = {'simkl': int(simkl_id)}
    if media == 'movies':
        payload = {'movies': [{'ids': ids}]}
    else:
        payload = {'shows': [{'ids': ids, 'seasons': [{'number': int(season), 'episodes': [{'number': int(episode)}]}]}]}
    try:
        data = _post('/sync/history', payload)
        added = data.get('added') or {}
        if added.get('movies') or added.get('episodes') or added.get('shows'):
            control.notify('Simkl', 'Watched history updated; reopen lists to refresh')
        else:
            control.notify('Simkl', 'Simkl accepted request; check watch history')
    except Exception as exc:
        control.log('Simkl watched update failed: %s' % exc, 'warning')
        _msg('Could not update Simkl: %s' % exc)


def change_status(media, simkl_id):
    import xbmcgui
    if media not in ('movies','shows') or not str(simkl_id).isdigit():
        return
    options = [(label, value) for label, value in statuses_for(media) if value != 'all']
    idx = xbmcgui.Dialog().select('Move title to Simkl watchlist', [label for label,value in options])
    if idx < 0:
        return
    label, value = options[idx]
    try:
        data = _post('/sync/add-to-list', {media: [{'ids': {'simkl':int(simkl_id)}, 'to':value}]})
        control.notify('Simkl', 'Status update accepted: %s' % label)
        import xbmc
        xbmc.executebuiltin('Container.Refresh')
    except Exception as exc:
        control.log('Simkl status change failed: %s' % exc,'warning')
        _msg('Could not change status: %s' % exc)


def _elementum_option(media, simkl_id, season, episode):
    """Provide Elementum source choices without initiating playback."""
    if media not in ('movies', 'shows'):
        return []
    try:
        import xbmcaddon
        xbmcaddon.Addon('plugin.video.elementum')
        details = _call('/movies/%s' % simkl_id if media == 'movies' else '/tv/%s' % simkl_id)
        tmdb = (details.get('ids') or {}).get('tmdb')
        if not tmdb or not str(tmdb).isdigit() or int(tmdb) <= 0:
            control.log('Simkl Elementum: no TMDb ID for %s %s' % (media, simkl_id), 'warning')
            if media == 'shows' and str(season).isdigit() and str(episode).isdigit() and int(episode) > 0:
                return [('Search Elementum for S%02dE%02d (title fallback)' % (int(season), int(episode)),
                         'simkl_elementum_episode_search/%s/%s/%s' % (int(simkl_id), int(season), int(episode)))]
            return []
        if media == 'movies':
            return [('Browse matching Elementum movie torrents',
                     'simkl_elementum_filtered/%s/%s' % (int(simkl_id), int(tmdb)))]
        season, episode = int(season), int(episode)
        if season < 0 or episode < 1:
            return []
        return [('Browse Elementum torrents for S%02dE%02d' % (season, episode),
                 'simkl_elementum_episode/%d/%d/%d/%d' %
                 (int(simkl_id), int(tmdb), season, episode))]
    except Exception as exc:
        control.log('Simkl Elementum navigation unavailable: %s' % exc, 'warning')
        return []


def play_elementum(media, tmdb, season, episode):
    """Old cached v0.9.0 action remains intentionally disabled."""
    _msg("The old Elementum PlayMedia action is disabled. Reopen the movie source list and select Find this movie's torrents in Elementum (test).")


def context_action(kind, original_url):
    # The supplied URL must be Simkl's own known navigation route. Never allow
    # arbitrary execution or an external plugin path through context menu.
    parts = original_url.strip('/').split('/')
    if kind == 'reset_resume':
        import xbmc
        import xbmcgui
        movie = None
        episode = None
        if len(parts) == 3 and parts[0] == 'simkl_elementum_filtered' and all(p.isdigit() for p in parts[1:]):
            movie = parts[1]
        elif len(parts) == 2 and parts[0] in ('simkl_movie_scrubs', 'simkl_resume_choices') and parts[1].isdigit():
            movie = parts[1]
        elif len(parts) == 3 and parts[:2] == ['simkl_media_detail', 'movies'] and parts[2].isdigit():
            movie = parts[2]
        elif len(parts) == 5 and parts[0] == 'simkl_media_sources' and all(p.isdigit() for p in parts[2:]):
            if parts[1] == 'movies':
                movie = parts[2]
            elif parts[1] == 'shows' and int(parts[4]) > 0:
                episode = parts[2:]
        if len(parts)==4 and parts[0]=='simkl_tv_episode' and all(p.isdigit() for p in parts[1:]):
            episode=parts[1:]
        if movie is None and episode is None:
            return
        if xbmc.Player().isPlayingVideo():
            control.notify('Simkl', 'Stop playback before resetting resume time.')
            return
        if not xbmcgui.Dialog().yesno('Reset Resume Time', 'Clear the saved playback position? Watchlist status and watched history will not change.'):
            return
        try:
            if movie is not None:
                from resources.lib.simkl_resume import reset_progress
                reset_progress(movie)
            else:
                from resources.lib.simkl_episode_tracking import reset_partial
                reset_partial(*episode)
            control.notify('Simkl', 'Saved Simkl resume time reset')
            xbmc.executebuiltin('Container.Refresh')
        except Exception as exc:
            control.log('Simkl resume reset failed: %s' % exc, 'warning')
            control.notify('Simkl', 'Could not reset resume time')
        return
    if kind == 'watched':
        if len(parts) == 4 and parts[0] == 'simkl_tv_episode' and all(p.isdigit() for p in parts[1:]):
            return mark_watched('shows', *parts[1:])
        if len(parts) == 5 and parts[0] == 'simkl_media_sources' and parts[1] == 'shows':
            return mark_watched(*parts[1:])
    elif kind == 'status':
        if len(parts) == 3 and parts[0] == 'simkl_elementum_filtered' and all(p.isdigit() for p in parts[1:]):
            return change_status('movies', parts[1])
        if len(parts) == 2 and parts[0] in ('simkl_movie_scrubs', 'simkl_resume_choices') and parts[1].isdigit():
            return change_status('movies', parts[1])
        if len(parts) in (3, 4) and parts[0] == 'simkl_media_detail' and parts[1] in ('movies','shows') and (len(parts) == 3 or (parts[1] == 'shows' and parts[3] == 'elementum')):
            return change_status(parts[1], parts[2])
        if len(parts) == 5 and parts[0] == 'simkl_media_sources' and parts[1] == 'movies':
            return change_status('movies', parts[2])
    control.log('Ignored invalid Simkl context action: %s / %s' % (kind, original_url), 'warning')


def _release_matches_movie(release, title, year):
    """Conservative filter: block obvious series packs / different years.

    Filenames aren't authoritative metadata. When uncertain, exclude rather
    than accidentally show a different film. Used only for Movies, not anime.
    """
    name = re.sub(r'\[[^]]*\]', ' ', str(release or '')).lower()
    if not name or not title:
        return False
    if re.search(r'\b(complete[ ._-]*series|series[ ._-]*pack|season[ ._-]*\d+|s\d{1,2}e\d{1,2}|collection[ ._-]*pack)\b', name):
        return False
    # Explicit wrong release year = wrong movie, even when the title is close.
    years = {int(y) for y in re.findall(r'(?<!\d)(?:19\d{2}|20\d{2})(?!\d)', name)}
    if year and years and int(year) not in years:
        return False
    stop = {'the','a','an','and','of','in','to','for'}
    words = [w for w in re.findall(r'[a-z0-9]+', title.lower()) if w not in stop]
    candidate_words = set(re.findall(r'[a-z0-9]+', name))
    if not words or not all(w in candidate_words for w in words):
        return False
    # Conservative for ambiguous movie titles: require release year in title.
    if year and int(year) not in years:
        return False
    return True


def _release_matches_episode(name, title, season, episode):
    """Match only explicit SxxExx or NxEE releases of this TV show.

    A plain season pack is deliberately excluded: its containing file may not
    be the episode chosen in Simkl. This does not verify language or audio.
    """
    words = re.findall(r'[a-z0-9]+', (title or '').lower())
    stop = {'the', 'a', 'an', 'and', 'of', 'in', 'to', 'for', 'tv', 'series'}
    required = [word for word in words if word not in stop]
    release = re.sub(r'\[[^]]*\]', ' ', str(name or '')).lower()
    seen = set(re.findall(r'[a-z0-9]+', release))
    if not required or not all(word in seen for word in required):
        return False
    pairs = []
    pairs.extend((int(s), int(e)) for s,e in re.findall(r'(?<![a-z0-9])s(\d{1,2})[ ._-]*e(\d{1,3})(?!\d)', release))
    pairs.extend((int(s), int(e)) for s,e in re.findall(r'(?<![a-z0-9])(\d{1,2})x(\d{1,3})(?!\d)', release))
    # Multiple-episode pack names are intentionally not shown by this filter.
    return bool(pairs) and all(pair == (int(season), int(episode)) for pair in pairs)


def draw_elementum_episode(simkl_id, tmdb_id, season, episode):
    """List Elementum's actual episode links, never a nested PlayMedia call."""
    import xbmcaddon
    from urllib.request import Request, urlopen

    simkl_id, tmdb_id, season, episode = (int(x) for x in (simkl_id, tmdb_id, season, episode))
    fallback = ('plugin://plugin.video.elementum/show/%d/season/%d/episode/%d/links?list=1'
                % (tmdb_id, season, episode))
    rows, accepted, error = [], set(), None
    try:
        addon = xbmcaddon.Addon('plugin.video.elementum')
        details = _call('/tv/%d' % simkl_id)
        if str((details.get('ids') or {}).get('tmdb') or '') != str(tmdb_id):
            raise ValueError('Show ID changed; reopen episode playback options')
        title = details.get('title') or ''
        if not title:
            raise ValueError('Show title unavailable')
        host = (addon.getSetting('remote_host') or '127.0.0.1').strip()
        if host not in ('127.0.0.1', 'localhost', '::1'):
            raise ValueError('Elementum remote-server configuration is not supported by this filter')
        port = int(addon.getSetting('remote_port') or '65220')
        if not 1 <= port <= 65535:
            raise ValueError('Elementum port is invalid')
        from resources.lib.simkl_elementum_start import wait_for_engine
        wait_for_engine(port)
        api = ('http://127.0.0.1:%d/show/%d/season/%d/episode/%d/links?list=1'
               % (port, tmdb_id, season, episode))
        with urlopen(Request(api, headers={'User-Agent':'Simkl-Kodi/0.9.18'}), timeout=55) as response:
            data = json.loads(response.read().decode('utf-8'))
        if not isinstance(data, dict) or not isinstance(data.get('items'), list):
            raise ValueError('Elementum did not return a playable source list')
        for item in data['items']:
            if not isinstance(item, dict):
                continue
            path = str(item.get('path') or '')
            label = str(item.get('label') or '')
            if not item.get('is_playable') or not path.startswith('plugin://plugin.video.elementum/play?'):
                continue
            if path in accepted or not _release_matches_episode(label, title, season, episode):
                continue
            accepted.add(path)
            rows.append(utils.allocate_item(label, path, False, True, [], 'tv_shows.png',
                        {'title':label, 'season':season, 'episode':episode,
                         'plot':'Elementum result for %s S%02dE%02d' % (title, season, episode)}))
        if not rows:
            error = 'No explicitly matching episode sources. Check native Elementum results.'
    except Exception as exc:
        error = '%s: %s' % (type(exc).__name__, exc)
        control.log('Simkl TV Elementum source browsing failed: %s' % error, 'warning')
    if error:
        rows.append(utils.allocate_item('Filter unavailable: %s' % error[:145],
                                        'simkl_action_help', False, False, [], 'tools.png', {}))
        rows.append(utils.allocate_item('Open native Elementum episode results (fallback)',
                                        fallback, True, False, [], 'tv_shows.png', {}))
    # A Kodi folder is completed exactly once; no modal dialogs during loading.
    control.draw_items(rows, 'episodes')


def draw_elementum_episode_search(simkl_id, season, episode):
    """Fallback for shows lacking a valid TMDb ID. User selects a source."""
    from urllib.parse import quote
    try:
        simkl_id, season, episode = int(simkl_id), int(season), int(episode)
        if simkl_id <= 0 or season < 0 or episode < 1:
            raise ValueError('Invalid show or episode')
        details = _call('/tv/%d' % simkl_id)
        title = str(details.get('title') or '').strip()
        if not title:
            raise ValueError('Show title is unavailable')
        query = '%s S%02dE%02d' % (title, season, episode)
        target = 'plugin://plugin.video.elementum/search?q=' + quote(query, safe='')
        control.draw_items([_item('Search Elementum: %s' % query, target, 'tv_shows.png'),
                            _item('Confirm episode and audio language before playing',
                                  'simkl_action_help', 'tools.png')])
    except Exception as exc:
        control.log('TV Elementum fallback unavailable: %s' % exc, 'warning')
        control.draw_items([_item('TV search unavailable: %s' % str(exc)[:100],
                                  'simkl_action_help', 'tools.png')])

def draw_anime_elementum(mal_id, episode):
    """User-initiated alternate search, using the anime's original MAL identity.

    We do not pretend that MAL IDs are TMDb IDs. This intentionally does not
    modify the existing anime player, its source rules, or its 80% tracking.
    """
    import pickle
    from resources.lib.ui import database
    from urllib.parse import quote
    try:
        mal_id, episode = int(mal_id), int(episode)
        if mal_id < 1 or episode < 1:
            raise ValueError('Invalid anime or episode number')
        data = database.get_show(mal_id)
        if not data or not data.get('kodi_meta'):
            raise ValueError('Anime metadata is not available; open its episode list first')
        meta = pickle.loads(data['kodi_meta'])
        title = (meta.get('ename') or meta.get('title_userPreferred') or meta.get('title') or '').strip()
        if not title:
            raise ValueError('No anime title available for search')
        # Ask the provider to search dubbed releases specifically. Elementum
        # does not guarantee audio-language filtering, so the user must verify.
        try:
            from resources.lib.simkl_anime_fallback_tracking import arm_anime
            arm_anime(mal_id, episode, title)
        except Exception as exc:
            control.log('Simkl anime fallback tracker not armed: %s' % exc, 'warning')
        query = '%s %02d English Dub' % (title, episode)
        target = 'plugin://plugin.video.elementum/search?q=' + quote(query, safe='')
        control.draw_items([_item('Search Elementum: %s (episode %d, English dub)' % (title, episode), target),
                            _item('Check audio language before playing — search results are not verified',
                                  'simkl_action_help', 'tools.png')])
    except Exception as exc:
        control.log('Anime Elementum fallback failed: %s' % exc, 'warning')
        control.draw_items([_item('Anime Elementum fallback unavailable: %s' % str(exc)[:100],
                                  'simkl_action_help', 'tools.png')])

def draw_elementum_filtered(simkl_id, tmdb_id):
    """Read Elementum's source list and display matched links safely.

    We complete this directory only once, including when a remote request
    fails. Any failure leaves the known-working native Elementum list reachable.
    No source is auto-played and no busy dialog is opened by this handler.
    """
    import xbmcaddon
    from urllib.request import Request, urlopen

    fallback = 'plugin://plugin.video.elementum/movie/%d/links?list=1' % int(tmdb_id)
    rows = []
    error = None
    accepted = set()
    try:
        addon = xbmcaddon.Addon('plugin.video.elementum')
        details = _call('/movies/%s' % int(simkl_id))
        if not isinstance(details, dict):
            raise ValueError('Simkl movie details are unavailable')
        title, year = details.get('title', ''), details.get('year')
        ids = details.get('ids') or {}
        if str(ids.get('tmdb') or '') != str(tmdb_id):
            raise ValueError('Movie ID changed; reopen its playback options')
        host = (addon.getSetting('remote_host') or '127.0.0.1').strip()
        if host not in ('127.0.0.1', 'localhost', '::1'):
            raise ValueError('Elementum is configured for a remote server')
        port = int(addon.getSetting('remote_port') or '65220')
        if not 1 <= port <= 65535:
            raise ValueError('Elementum port is invalid')
        from resources.lib.simkl_elementum_start import wait_for_engine
        wait_for_engine(port)
        url = 'http://127.0.0.1:%d/movie/%d/links?list=1' % (port, int(tmdb_id))
        req = Request(url, headers={'User-Agent': 'Simkl-Kodi/0.9.8'})
        with urlopen(req, timeout=55) as response:
            data = json.loads(response.read().decode('utf-8'))
        if not isinstance(data, dict) or not isinstance(data.get('items'), list):
            raise ValueError('Elementum returned an unexpected source-list format')
        for item in data['items']:
            if not isinstance(item, dict):
                continue
            path, name = str(item.get('path') or ''), str(item.get('label') or '')
            if not item.get('is_playable') or not path.startswith('plugin://plugin.video.elementum/play?'):
                continue
            if not _release_matches_movie(name, title, year) or path in accepted:
                continue
            accepted.add(path)
            rows.append(utils.allocate_item(name, path, False, True, [], 'movies.png',
                            {'title':name, 'plot':'Elementum result for %s (%s)' % (title, year)}))
        if not rows:
            error = 'No exact title/year matches. Review Elementum results manually.'
        else:
            from resources.lib.simkl_resume import cache_sources
            cache_sources(simkl_id, data['items'])
    except Exception as exc:
        error = '%s: %s' % (type(exc).__name__, exc)
        control.log('Simkl Elementum filtered listing failed: %s' % error, 'warning')

    if error:
        # Display the error as a non-playable item; do not open a modal dialog
        # while Kodi is loading a directory, and do not attempt a second draw.
        rows.append(utils.allocate_item('Filter unavailable: %s' % error[:150],
                    'simkl_action_help', False, False, [], 'tools.png', {}))
        rows.append(utils.allocate_item('Open unfiltered Elementum results (fallback)',
                    fallback, True, False, [], 'movies.png', {}))
    # Arm only if the filtered list actually returned playable torrent entries.
    # No media is started here; the Kodi service listens for playback separately.
    if accepted and not error:
        try:
            from resources.lib.simkl_playback_tracking import arm_movie
            arm_movie(simkl_id, tmdb_id, title, year)
        except Exception as exc:
            control.log('Simkl tracker arming failed: %s' % exc, 'warning')
    control.draw_items(rows, 'videos')



def draw_resume_choices(simkl_id):
    """Three plain Kodi navigation choices, avoiding crash-prone modal dialogs."""
    from resources.lib.simkl_resume import resume_data
    saved = resume_data(simkl_id, force=True)
    pct = float(saved.get('percentage') or 0)
    rows = []
    if pct <= 0 or pct >= 80:
        rows.append(_item('No unfinished playback found; choose a movie source',
                          'simkl_resume_launch/%s/start' % simkl_id))
    else:
        source = saved.get('source') or {}
        if str(source.get('path') or '').startswith('plugin://plugin.video.elementum/play?'):
            rows.append(_item('Resume same torrent at %d%%' % round(pct),
                              'simkl_resume_launch/%s/same' % simkl_id))
        rows.append(_item('Choose another source (resume from %.1f%%)' % pct,
                          'simkl_resume_launch/%s/other' % simkl_id))
        rows.append(_item('Start from beginning (0:00)',
                          'simkl_resume_launch/%s/start' % simkl_id))
    control.draw_items(rows)


def draw_resume_launch(simkl_id, mode):
    """Never invoke PlayMedia/Container.Update. Display a playable link."""
    from resources.lib.simkl_resume import resume_data, set_resume_request
    from resources.lib.simkl_playback_tracking import arm_movie
    saved = resume_data(simkl_id, force=True)
    target = int(saved.get('seconds') or 0)
    if not target and saved.get('percentage') and saved.get('total'):
        target = int(saved['total'] * float(saved['percentage']) / 100)
    if mode == 'start':
        target = 0
    set_resume_request(simkl_id, target, 0 if mode == 'start' else saved.get('percentage') or 0)
    try:
        details = _call('/movies/%s' % simkl_id)
        ids = details.get('ids') or {}
        tmdb = ids.get('tmdb')
        if not tmdb or not str(tmdb).isdigit():
            raise ValueError('Missing TMDb movie ID')
        if mode == 'same':
            source = (saved.get('source') or {}).get('path') or ''
            if not source.startswith('plugin://plugin.video.elementum/play?'):
                raise ValueError('Exact source is unavailable; use Choose another torrent')
            arm_movie(simkl_id, tmdb, details.get('title'), details.get('year'))
            control.draw_items([utils.allocate_item('Play saved torrent' +
                                (' — resume at %d seconds' % target if target else ''),
                                source, False, True, [], 'movies.png',
                                {'title':details.get('title') or '', 'year':details.get('year') or 0})], 'videos')
        elif mode in ('other', 'start'):
            # The listing arms tracking after successfully retrieving sources.
            draw_elementum_filtered(simkl_id, tmdb)
        else:
            control.draw_items([])
    except Exception as exc:
        control.log('Simkl resume open failed: %s' % exc, 'warning')
        control.draw_items([_item('Resume unavailable: %s' % str(exc)[:110], 'simkl_action_help')])


def draw_tv_episode(sid, season, episode):
    from resources.lib.simkl_episode_tracking import bookmark, arm_episode
    details = _call('/tv/%s' % int(sid))
    tmdb = (details.get('ids') or {}).get('tmdb')
    if not str(tmdb or '').isdigit():
        draw_sources('shows', sid, season, episode)
        return
    saved = bookmark(sid, season, episode)
    rows = []
    if 0 < float(saved.get('percentage') or 0) < 80:
        rows.append(_item('Resume — %d%%' % round(saved['percentage']), 'simkl_tv_links/%s/%s/%s/resume' % (sid,season,episode), 'tv_shows.png'))
    rows.append(_item('Start Over' if rows else 'Find episode sources', 'simkl_tv_links/%s/%s/%s/start' % (sid,season,episode), 'tv_shows.png'))
    control.draw_items(rows)


def _single_elementum_resume_prompt():
    # Elementum enum 0 delegates resume prompts to Kodi; 1 asks again.
    try:
        import xbmcaddon
        addon = xbmcaddon.Addon('plugin.video.elementum')
        if addon.getSetting('play_resume_action') != '0':
            addon.setSetting('play_resume_action', '0')
    except Exception as exc:
        control.log('Simkl could not set Elementum resume mode: %s' % exc, 'warning')


def draw_tv_links(sid, season, episode, mode):
    _single_elementum_resume_prompt()
    from resources.lib.simkl_episode_tracking import arm_episode
    details = _call('/tv/%s' % int(sid))
    tmdb = int(details['ids']['tmdb'])
    arm_episode(sid, season, episode, details['title'], mode, tmdb)
    target = 'plugin://plugin.video.elementum/show/%d/season/%d/episode/%d/links?list=1' % (tmdb,int(season),int(episode))
    control.draw_items([_item('Elementum — episode sources', target, 'tv_shows.png')])
