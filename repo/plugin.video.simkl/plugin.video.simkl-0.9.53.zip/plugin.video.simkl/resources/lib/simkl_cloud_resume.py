"""Account-scoped playback cache; remote failures never erase local bookmarks."""
import time, os, json, hashlib
from datetime import datetime
from resources.lib.ui import control

def path():
    scope=hashlib.sha256((control.getSetting('simkl.token') or '').encode()).hexdigest()[:20]
    return os.path.join(control.dataPath,'resume-cloud-'+scope+'.json')

def load():
    try:
        with open(path(),encoding='utf-8') as f:return json.load(f)
    except (OSError,ValueError):return {}

def save(data):
    from resources.lib.simkl_resume import _atomic_local
    os.makedirs(control.dataPath,exist_ok=True)
    _atomic_local(path(),data)

def stamp(value):
    try:return datetime.fromisoformat(str(value).replace('Z','+00:00')).timestamp()
    except (ValueError,TypeError):return 0

def refresh(force=False):
    from resources.lib.simkl_media import _call
    old=load()
    if not force and time.time()-old.get('attempt',0)<60:return old
    old['attempt']=time.time()
    try:
        rows=_call('/sync/playback')
        if not isinstance(rows,list):raise ValueError('Expected playback list')
        records={}
        for row in rows:
            movie=row.get('movie') or {}; show=row.get('show') or {}; ep=row.get('episode') or {}
            sid=((movie or show).get('ids') or {}).get('simkl')
            if not sid:continue
            if movie:key='movie:'+str(sid)
            elif show and ep.get('season') is not None and ep.get('number') is not None:key='episode:%s:%s:%s'%(sid,ep['season'],ep['number'])
            else:continue
            pct=float(row.get('progress') or 0)
            if not 0<pct<80:continue
            rec={'percentage':pct,'updated':stamp(row.get('paused_at') or row.get('updated_at')),'remote_id':row.get('id')}
            if key not in records or rec['updated']>=records[key]['updated']:records[key]=rec
        old.update(records=records,download=time.time(),error='')
    except Exception as exc:old['error']=type(exc).__name__+': '+str(exc)[:120]
    save(old);return old

def merge(key,local,force=False):
    from resources.lib.simkl_drive import refresh as drive_refresh
    drive=drive_refresh(force).get(key,{})
    if drive and float(drive.get('updated',0))>float(local.get('updated',0)):
        local=drive
    # Drive contains exact elapsed time; SIMKL may report a delayed percentage.
    if drive and float(drive.get('updated',0))>=float(local.get('updated',0)):
        return local
    remote=refresh(force).get('records',{}).get(key,{})
    if not remote:return local
    if local and (not remote.get('updated') or remote['updated']<=local.get('updated',0)):return local
    result=dict(local);result.update(remote);result.pop('reset',None);result.pop('finished',None);result.pop('completed',None)
    result['seconds']=round(float(result.get('total') or 0)*remote['percentage']/100)
    return result

def upload(payload,action='stop'):
    from resources.lib.simkl_media import _post
    _post('/scrobble/'+action,payload)
    data=load();data['upload']=time.time();save(data)

def reset(key):
    from resources.lib.simkl_media import _headers,client
    data=refresh(True)
    if data.get('error'):raise RuntimeError('Cannot verify remote bookmark')
    rid=data.get('records',{}).get(key,{}).get('remote_id')
    if rid is not None:
        response=client.delete('https://api.simkl.com/sync/playback/'+str(int(rid)),headers=_headers())
        if response is None or not 200<=response.status_code<300:raise RuntimeError('Remote reset failed')
        refresh(True)

def tools():
    data=refresh(True)
    def fmt(k):return time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(data[k])) if data.get(k) else 'Not yet recorded'
    control.ok_dialog('Simkl Resume Sync','Last download: '+fmt('download')+'\nLast upload: '+fmt('upload')+'\nBookmarks: '+str(len(data.get('records',{})))+'\n'+(data.get('error') or 'Download successful'))
