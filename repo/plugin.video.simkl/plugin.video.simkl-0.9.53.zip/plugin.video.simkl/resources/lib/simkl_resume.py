"""Optional resume records, separate from Simkl's official watch history.

Simkl scrobble/stop stores progress across devices. Exact torrent source paths
are kept locally or in a user-configured shared Kodi folder, never sent to Simkl.
No navigation or playback is triggered from this module.
"""
import hashlib
import json
import os
import re
import time
from urllib.parse import urlsplit, parse_qs, unquote

from resources.lib.ui import control


def _local_dir():
    path = os.path.join(control.dataPath, 'simkl_resumes')
    os.makedirs(path, exist_ok=True)
    return path


def _key(simkl_id):
    return str(int(simkl_id))


def _local_file(simkl_id):
    return os.path.join(_local_dir(), _key(simkl_id) + '.json')


def _shared_file(simkl_id):
    # Kodi vfs paths can be smb://, nfs://, or another user-configured source.
    # No network share is presumed or automatically configured.
    folder = (control.getSetting('simkl.resume.shared_folder') or '').strip()
    if not folder:
        return ''
    token = control.getSetting('simkl.token') or ''
    if not token:
        return ''
    # Avoid disclosing the raw Simkl token in the filename.
    scope = hashlib.sha256(token.encode('utf-8')).hexdigest()[:20]
    return folder.rstrip('/\\') + '/simkl-' + scope + '-movie-' + _key(simkl_id) + '.json'


def _safe_read(filename, vfs=False):
    try:
        if vfs:
            import xbmcvfs
            if not xbmcvfs.exists(filename):
                return {}
            f = xbmcvfs.File(filename, 'r')
            try:
                contents = f.read()
            finally:
                f.close()
        else:
            with open(filename, encoding='utf-8') as f:
                contents = f.read()
        obj = json.loads(contents)
        return obj if isinstance(obj, dict) else {}
    except FileNotFoundError:
        return {}
    except Exception as exc:
        control.log('Simkl resume read unavailable: %s' % exc, 'warning')
        return {}


def _atomic_local(filename, obj):
    tmp = filename + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(obj, f)
    os.replace(tmp, filename)


def _write_shared(filename, obj):
    if not filename:
        return
    try:
        import xbmcvfs
        # Only write into a folder explicitly configured by the user.
        f = xbmcvfs.File(filename, 'w')
        try:
            f.write(json.dumps(obj))
        finally:
            f.close()
    except Exception as exc:
        control.log('Simkl shared resume write failed (check folder permissions): %s' % exc, 'warning')


def read_progress(simkl_id):
    local = _safe_read(_local_file(simkl_id))
    remote_path = _shared_file(simkl_id)
    remote = _safe_read(remote_path, vfs=True) if remote_path else {}
    candidates = [o for o in (local, remote) if o.get('simkl') == int(simkl_id)]
    return max(candidates, key=lambda o: float(o.get('updated') or 0)) if candidates else {}


def save_progress(arm, seconds, total, scrobble=False):
    """Persist even when Elementum exposes percentage but no usable duration."""
    sid = int(arm['simkl'])
    seconds, total = max(0, int(seconds)), max(0, int(total))
    player_pct = float(arm.get('pct') or 0)
    existing = read_progress(sid)
    if not total and seconds and 0 < player_pct < 100:
        total = int(round(seconds * 100.0 / player_pct))
    if not total and existing.get('total'):
        total = int(existing['total'])
    if not seconds and total and player_pct > 0:
        seconds = int(round(total * player_pct / 100.0))
    if total and seconds:
        pct = max(0., min(100., 100. * seconds / total))
    else:
        pct = max(0., min(100., player_pct))
    if pct <= 0 or pct >= 80 or (pct < 1 and seconds < 120):
        return False
    obj = {'simkl': sid, 'tmdb': int(arm['tmdb']), 'title': arm['title'],
           'year': arm['year'], 'seconds': seconds, 'total': total,
           'percentage': round(pct, 2),
           'source': arm.get('selected_source') or existing.get('source') or {},
           'updated': time.time()}
    _atomic_local(_local_file(sid), obj)
    # A local bookmark does not depend on the Simkl API or a shared folder.
    if scrobble:
        from resources.lib.simkl_drive import enqueue
        enqueue("movie:"+str(sid), obj)
        _write_shared(_shared_file(sid), obj)
        from resources.lib.simkl_cloud_resume import upload
        try:
            upload({'progress': round(pct, 2),
                  'movie': {'title':arm['title'], 'year':arm['year'],
                            'ids':{'simkl':sid, 'tmdb':int(arm['tmdb'])}}})
            control.log('Simkl stopped playback saved remotely at %.1f%% for %s' % (pct, sid), 'info')
        except Exception as exc:
            control.log('Simkl remote playback sync failed: %s' % exc, 'warning')
    return True


def clear_progress(simkl_id):
    # Use tombstone in shared storage; old records on other devices must not resurrect.
    obj = {'simkl':int(simkl_id), 'updated':time.time(), 'finished':True}
    _atomic_local(_local_file(simkl_id), obj)
    _write_shared(_shared_file(simkl_id), obj)
    from resources.lib.simkl_drive import enqueue
    enqueue("movie:"+str(int(simkl_id)), obj)


def reset_progress(simkl_id):
    # Explicit reset overrides stale server progress until new local playback.
    obj = {'simkl': int(simkl_id), 'updated': time.time(), 'reset': True}
    _atomic_local(_local_file(simkl_id), obj)
    _write_shared(_shared_file(simkl_id), obj)
    from resources.lib.simkl_drive import enqueue
    enqueue("movie:"+str(int(simkl_id)), obj)
    set_resume_request(simkl_id, 0, 0)
    from resources.lib.simkl_cloud_resume import reset
    reset("movie:"+str(int(simkl_id)))


def _play_url(item):
    path = str(item.get('file') or '')
    return path if path.startswith('plugin://plugin.video.elementum/play?') else ''


def _infohash(url):
    try:
        params = parse_qs(urlsplit(url).query)
        magnet = params.get('uri', [''])[0]
        found = re.search(r'btih:([A-Fa-f0-9]{40}|[A-Z2-7]{32})', magnet, re.I)
        return found.group(1).lower() if found else ''
    except Exception:
        return ''


def cache_sources(simkl_id, rows):
    choices = []
    for item in rows:
        url = str(item.get('path') or '')
        if not url.startswith('plugin://plugin.video.elementum/play?'):
            continue
        choices.append({'path':url, 'label':str(item.get('label') or ''), 'hash':_infohash(url)})
    _atomic_local(os.path.join(_local_dir(), 'sources-' + _key(simkl_id) + '.json'),
                  {'updated':time.time(), 'sources':choices})


def detect_torrent(simkl_id, item):
    direct = _play_url(item)
    if direct:
        return {'path':direct, 'hash':_infohash(direct)}
    # If the player only exposes a /files/ stream, identify its exact hash;
    # never blindly pick the first torrent in a search-result list.
    file_path = str(item.get('file') or '').lower()
    cached = _safe_read(os.path.join(_local_dir(), 'sources-' + _key(simkl_id) + '.json'))
    candidates = cached.get('sources') or []
    matches = [o for o in candidates if o.get('hash') and o['hash'] in file_path]
    if len(matches) == 1:
        return matches[0]
    # Some Elementum versions expose only the played video's filename.
    # Accept a single unambiguous filename match, never infer by movie title alone.
    if not matches and '/files/' in file_path:
        from urllib.parse import unquote
        filename = unquote(file_path.rsplit('/', 1)[-1]).lower()
        tokens = re.findall(r'[a-z0-9]+', filename)
        if len(tokens) >= 6:
            stem = ' '.join(tokens[:min(8, len(tokens))])
            normalized = lambda value: ' '.join(re.findall(r'[a-z0-9]+', value.lower()))
            matched = [o for o in candidates if stem in normalized(o.get('label') or '')]
            if len(matched) == 1:
                return matched[0]
    return {}


def resume_data(simkl_id, force=False):
    from resources.lib.simkl_cloud_resume import merge
    return merge('movie:'+str(int(simkl_id)), read_progress(simkl_id), force)


def set_resume_request(simkl_id, target, pct=0):
    path = os.path.join(_local_dir(), 'request-' + _key(simkl_id) + '.json')
    _atomic_local(path, {'seconds':int(target), 'percentage':float(pct), 'updated':time.time()})


def get_resume_request(simkl_id):
    path = os.path.join(_local_dir(), 'request-' + _key(simkl_id) + '.json')
    record = _safe_read(path)
    if time.time() - float(record.get('updated') or 0) > 180:
        return {}
    return record
